"""
Instructions for registering your Telegram bot with BotFather.

Follow these steps to create your bot and get the required token:

1. Open Telegram and search for @BotFather
2. Start a chat with BotFather by clicking "Start"
3. Send the command /newbot
4. Follow the prompts to choose a name and username for your bot
   - The name can be anything you want
   - The username must end with "bot" (e.g., MirrorServiceBot)
5. Once created, BotFather will provide you with a token
6. Copy this token and add it to your .env file as BOT_TOKEN

Example conversation with BotFather:

You: /newbot
BotFather: Alright, a new bot. How are we going to call it? Please choose a name for your bot.
You: Mirror Service Bot
BotFather: Good. Now let's choose a username for your bot. It must end in `bot`. Like this, for example: TetrisBot or tetris_bot.
You: MirrorServiceBot
BotFather: Done! Congratulations on your new bot. You will find it at t.me/MirrorServiceBot. You can now add a description, about section and profile picture for your bot, see /help for a list of commands. By the way, when you've finished creating your cool bot, ping our Bot Support if you want a better username for it. Just make sure the bot is fully operational before you do this.

Use this token to access the HTTP API:
1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi

Keep your token secure and store it safely, it can be used by anyone to control your bot.

Additional Bot Settings:

After creating your bot, you can configure additional settings using these BotFather commands:
- /setdescription - Change the bot description
- /setabouttext - Change the bot about info
- /setuserpic - Change the bot profile photo
- /setcommands - Change the list of commands

Recommended commands to set up:
/setcommands
start - Start the bot
help - Show help information

For privacy and security, you may want to disable group chats:
/setjoingroups
Choose your bot, then select "Disable"
"""
