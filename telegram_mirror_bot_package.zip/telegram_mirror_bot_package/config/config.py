"""
Configuration module for the Telegram Mirror Bot.
"""
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Bot Configuration
BOT_TOKEN = os.getenv('BOT_TOKEN')
BOT_USERNAME = os.getenv('BOT_USERNAME')

# External Server Configuration
SERVER_URL = os.getenv('SERVER_URL')
SERVER_API_KEY = os.getenv('SERVER_API_KEY')
SERVER_TIMEOUT = int(os.getenv('SERVER_TIMEOUT', '30'))

# Payment Configuration
COMMISSION_PERCENTAGE = float(os.getenv('COMMISSION_PERCENTAGE', '5.0'))
PAYMENT_WALLET_ADDRESS = os.getenv('PAYMENT_WALLET_ADDRESS')
STRIPE_API_KEY = os.getenv('STRIPE_API_KEY')
COINBASE_API_KEY = os.getenv('COINBASE_API_KEY')
COINBASE_WEBHOOK_SECRET = os.getenv('COINBASE_WEBHOOK_SECRET')

# Admin Configuration
ADMIN_USERNAMES = os.getenv('ADMIN_USERNAMES', '').split(',')
ADMIN_PANEL_PORT = int(os.getenv('ADMIN_PANEL_PORT', '5000'))
ADMIN_PANEL_USERNAME = os.getenv('ADMIN_PANEL_USERNAME')
ADMIN_PANEL_PASSWORD = os.getenv('ADMIN_PANEL_PASSWORD')

# Logging Configuration
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
LOG_FILE = os.getenv('LOG_FILE', 'logs/bot.log')

# Security Configuration
ENCRYPTION_KEY = os.getenv('ENCRYPTION_KEY')
