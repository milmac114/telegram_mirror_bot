#!/bin/bash
# Deployment script for Telegram Mirror Bot

# Exit on error
set -e

# Configuration
DEPLOY_DIR="/opt/telegram_mirror_bot"
LOG_DIR="/var/log/telegram_mirror_bot"
SERVICE_NAME="telegram_mirror_bot"
GITHUB_REPO="https://github.com/yourusername/telegram_mirror_bot.git"
BRANCH="main"

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Print colored message
print_message() {
    echo -e "${GREEN}[DEPLOY]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "Please run as root"
    exit 1
fi

# Create directories if they don't exist
print_message "Creating directories..."
mkdir -p $DEPLOY_DIR
mkdir -p $LOG_DIR

# Set proper permissions
chown -R ubuntu:ubuntu $DEPLOY_DIR
chown -R ubuntu:ubuntu $LOG_DIR

# Check if .env file exists
if [ ! -f ".env" ]; then
    print_error ".env file not found. Please create it before deploying."
    exit 1
fi

# Deploy from current directory or git
if [ "$1" == "--from-git" ]; then
    print_message "Deploying from Git repository..."
    
    # Clone or update repository
    if [ -d "$DEPLOY_DIR/.git" ]; then
        cd $DEPLOY_DIR
        git fetch origin
        git checkout $BRANCH
        git pull origin $BRANCH
    else
        git clone -b $BRANCH $GITHUB_REPO $DEPLOY_DIR
    fi
else
    print_message "Deploying from current directory..."
    
    # Copy files to deployment directory
    rsync -av --exclude 'venv' --exclude '.git' --exclude '__pycache__' --exclude '*.pyc' ./ $DEPLOY_DIR/
fi

# Copy .env file
cp .env $DEPLOY_DIR/

# Set up virtual environment
print_message "Setting up virtual environment..."
cd $DEPLOY_DIR
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Create systemd service file
print_message "Creating systemd service..."
cat > /etc/systemd/system/$SERVICE_NAME.service << EOF
[Unit]
Description=Telegram Mirror Bot
After=network.target

[Service]
User=ubuntu
Group=ubuntu
WorkingDirectory=$DEPLOY_DIR
ExecStart=$DEPLOY_DIR/venv/bin/python $DEPLOY_DIR/main.py
Restart=always
RestartSec=10
StandardOutput=append:$LOG_DIR/bot.log
StandardError=append:$LOG_DIR/error.log
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd
systemctl daemon-reload

# Run tests
print_message "Running tests..."
cd $DEPLOY_DIR
source venv/bin/activate
python -m unittest discover tests

# If tests pass, start the service
if [ $? -eq 0 ]; then
    print_message "Tests passed. Starting service..."
    systemctl enable $SERVICE_NAME
    systemctl restart $SERVICE_NAME
    
    # Check if service is running
    if systemctl is-active --quiet $SERVICE_NAME; then
        print_message "Service is running. Deployment successful!"
    else
        print_error "Service failed to start. Check logs for details."
        journalctl -u $SERVICE_NAME -n 50
        exit 1
    fi
else
    print_error "Tests failed. Deployment aborted."
    exit 1
fi

# Set up log rotation
print_message "Setting up log rotation..."
cat > /etc/logrotate.d/$SERVICE_NAME << EOF
$LOG_DIR/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 ubuntu ubuntu
    sharedscripts
    postrotate
        systemctl reload $SERVICE_NAME
    endscript
}
EOF

print_message "Deployment completed successfully!"
print_message "Bot is running as a systemd service: $SERVICE_NAME"
print_message "Logs are available at: $LOG_DIR"
print_message "To check status: systemctl status $SERVICE_NAME"
print_message "To view logs: journalctl -u $SERVICE_NAME -f"
