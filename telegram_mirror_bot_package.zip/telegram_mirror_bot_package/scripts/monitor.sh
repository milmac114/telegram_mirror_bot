#!/bin/bash
# Monitoring script for Telegram Mirror Bot

# Configuration
SERVICE_NAME="telegram_mirror_bot"
LOG_DIR="/var/log/telegram_mirror_bot"
ADMIN_EMAIL="admin@example.com"
WEBHOOK_URL="https://hooks.slack.com/services/your/webhook/url"
CHECK_INTERVAL=300  # 5 minutes

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Print colored message
print_message() {
    echo -e "${GREEN}[MONITOR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Send notification
send_notification() {
    local subject="$1"
    local message="$2"
    local severity="$3"
    
    # Send email notification
    echo "$message" | mail -s "$subject" $ADMIN_EMAIL
    
    # Send webhook notification (e.g., to Slack)
    if [ -n "$WEBHOOK_URL" ]; then
        curl -s -X POST -H 'Content-type: application/json' \
            --data "{\"text\":\"*$subject*\n$message\", \"color\":\"$severity\"}" \
            $WEBHOOK_URL
    fi
    
    print_message "Notification sent: $subject"
}

# Check if service is running
check_service() {
    if ! systemctl is-active --quiet $SERVICE_NAME; then
        print_error "Service $SERVICE_NAME is not running!"
        send_notification "CRITICAL: Bot Service Down" "The Telegram Mirror Bot service is not running. Please check the server." "danger"
        
        # Try to restart the service
        systemctl restart $SERVICE_NAME
        sleep 5
        
        if systemctl is-active --quiet $SERVICE_NAME; then
            print_message "Service successfully restarted."
            send_notification "RESOLVED: Bot Service Restored" "The Telegram Mirror Bot service has been automatically restarted and is now running." "good"
        else
            print_error "Failed to restart service."
            send_notification "CRITICAL: Bot Service Restart Failed" "Attempted to restart the Telegram Mirror Bot service but failed. Manual intervention required." "danger"
        fi
        
        return 1
    fi
    
    print_message "Service $SERVICE_NAME is running."
    return 0
}

# Check CPU and memory usage
check_resources() {
    # Get CPU usage of the bot process
    local pid=$(systemctl show -p MainPID $SERVICE_NAME | cut -d= -f2)
    
    if [ "$pid" -eq 0 ]; then
        print_error "Cannot find process ID for $SERVICE_NAME"
        return 1
    fi
    
    local cpu_usage=$(ps -p $pid -o %cpu | tail -n 1 | tr -d ' ')
    local mem_usage=$(ps -p $pid -o %mem | tail -n 1 | tr -d ' ')
    
    print_message "CPU usage: $cpu_usage%, Memory usage: $mem_usage%"
    
    # Check if CPU usage is too high
    if (( $(echo "$cpu_usage > 80" | bc -l) )); then
        print_warning "High CPU usage detected: $cpu_usage%"
        send_notification "WARNING: High CPU Usage" "The Telegram Mirror Bot is using $cpu_usage% CPU. Please investigate." "warning"
    fi
    
    # Check if memory usage is too high
    if (( $(echo "$mem_usage > 80" | bc -l) )); then
        print_warning "High memory usage detected: $mem_usage%"
        send_notification "WARNING: High Memory Usage" "The Telegram Mirror Bot is using $mem_usage% memory. Please investigate." "warning"
    fi
    
    return 0
}

# Check disk space
check_disk_space() {
    local disk_usage=$(df -h / | awk 'NR==2 {print $5}' | tr -d '%')
    
    print_message "Disk usage: $disk_usage%"
    
    if [ "$disk_usage" -gt 90 ]; then
        print_warning "Low disk space: $disk_usage%"
        send_notification "WARNING: Low Disk Space" "The server is running low on disk space ($disk_usage%). Please free up space." "warning"
    fi
    
    return 0
}

# Check log for errors
check_logs() {
    local error_count=$(grep -c "ERROR" $LOG_DIR/error.log)
    local critical_count=$(grep -c "CRITICAL" $LOG_DIR/error.log)
    
    print_message "Found $error_count ERROR and $critical_count CRITICAL entries in logs"
    
    if [ "$critical_count" -gt 0 ]; then
        local recent_critical=$(grep "CRITICAL" $LOG_DIR/error.log | tail -n 5)
        print_error "Recent CRITICAL errors found in logs"
        send_notification "CRITICAL: Bot Errors Detected" "Found $critical_count CRITICAL errors in the bot logs. Recent errors:\n$recent_critical" "danger"
    elif [ "$error_count" -gt 10 ]; then
        local recent_errors=$(grep "ERROR" $LOG_DIR/error.log | tail -n 5)
        print_warning "High number of ERROR entries in logs"
        send_notification "WARNING: Bot Errors Detected" "Found $error_count ERROR entries in the bot logs. Recent errors:\n$recent_errors" "warning"
    fi
    
    return 0
}

# Check API connectivity
check_api_connectivity() {
    # This would normally check connectivity to external services
    # For demonstration, we'll just check internet connectivity
    if ! ping -c 1 api.telegram.org &> /dev/null; then
        print_error "Cannot connect to Telegram API"
        send_notification "CRITICAL: API Connectivity Issue" "The bot cannot connect to the Telegram API. Please check network connectivity." "danger"
        return 1
    fi
    
    print_message "API connectivity check passed"
    return 0
}

# Main monitoring loop
main() {
    print_message "Starting monitoring for $SERVICE_NAME"
    
    while true; do
        print_message "Running checks at $(date)"
        
        # Run all checks
        check_service
        check_resources
        check_disk_space
        check_logs
        check_api_connectivity
        
        print_message "Checks completed. Sleeping for $CHECK_INTERVAL seconds"
        sleep $CHECK_INTERVAL
    done
}

# Run as a one-time check if argument provided
if [ "$1" == "--check" ]; then
    check_service
    check_resources
    check_disk_space
    check_logs
    check_api_connectivity
    exit 0
fi

# Otherwise run the monitoring loop
main
