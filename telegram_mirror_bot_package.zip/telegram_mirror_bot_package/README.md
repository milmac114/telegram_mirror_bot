# Telegram Mirror Bot Documentation

## Overview
The Telegram Mirror Bot is a sophisticated application that mirrors an external server in real-time, allowing users to interact with it as if it were native to the bot. The bot provides seamless message relay, payment processing with commission handling, multiple payment methods, complete anonymity, and comprehensive admin tools.

## Features

### Server Mirroring
- Real-time message relay between users and external servers
- Support for text, photos, and document files
- Session management for continuous conversations
- Seamless response handling

### Payment Processing
- Multiple payment methods:
  - Credit card payments via Stripe
  - Cryptocurrency payments via Coinbase Commerce
  - Direct cryptocurrency wallet transfers
- Configurable commission percentage
- Secure fund forwarding to server owners
- Payment status tracking and verification

### Anonymity Features
- Complete server identity masking
- End-to-end encryption for secure communications
- User privacy protection
- Prevention of tracking and fingerprinting

### Admin Panel
- Secure authentication system
- Transaction monitoring and statistics
- Settings management
- User activity tracking
- Web interface and RESTful API

### Logging and Error Handling
- Comprehensive logging system with rotation
- Robust error handling with severity classification
- Notification system for critical errors
- Retry mechanisms for transient failures

## Installation

### Prerequisites
- Python 3.10 or higher
- pip package manager
- A Telegram Bot Token (from BotFather)
- Payment gateway accounts (Stripe, Coinbase Commerce)

### Setup
1. Clone the repository:
   ```
   git clone https://github.com/yourusername/telegram_mirror_bot.git
   cd telegram_mirror_bot
   ```

2. Create a virtual environment:
   ```
   python3 -m venv venv
   source venv/bin/activate
   ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Create a `.env` file with your configuration:
   ```
   BOT_TOKEN=your_telegram_bot_token
   EXTERNAL_SERVER_URL=https://your-external-server.com/api
   COMMISSION_PERCENTAGE=10
   STRIPE_API_KEY=your_stripe_api_key
   COINBASE_API_KEY=your_coinbase_api_key
   ADMIN_USERNAME=your_admin_username
   ADMIN_PASSWORD=your_admin_password
   ```

5. Run the bot:
   ```
   python main.py
   ```

### Deployment
For production deployment, use the included deployment script:
```
sudo ./deploy.sh
```

This will:
- Set up the bot as a systemd service
- Configure log rotation
- Run tests to ensure everything works
- Start the bot automatically

## Monitoring
The bot includes a monitoring script that checks:
- Service status
- CPU and memory usage
- Disk space
- Error logs
- API connectivity

To run a one-time check:
```
./monitor.sh --check
```

To start continuous monitoring:
```
./monitor.sh
```

## Development

### Project Structure
- `src/` - Main source code
  - `bot.py` - Main bot implementation
  - `server_proxy.py` - External server communication
  - `mirror_handler.py` - Message handling and processing
  - `payment_handler.py` - Payment processing
  - `session_manager.py` - User session management
  - `logger.py` - Logging system
  - `error_handler.py` - Error handling
  - `notifications.py` - Notification system
  - `anonymity/` - Anonymity features
  - `payment/` - Payment gateway integrations
  - `admin/` - Admin panel implementation
- `config/` - Configuration files
- `tests/` - Unit and integration tests
- `logs/` - Log files
- `docs/` - Documentation

### Testing
Run the test suite with:
```
python -m unittest discover tests
```

## Security Considerations
- All communications with external servers are encrypted
- User data is anonymized before forwarding
- Payment information is handled securely
- Admin panel requires secure authentication
- Sensitive configuration is stored in environment variables

## Customization
The bot is designed to be highly configurable:
- Payment commission percentage can be adjusted
- Multiple payment methods can be enabled/disabled
- Logging levels can be configured
- Error notification thresholds can be customized

## Troubleshooting
Common issues and solutions:
- Bot not responding: Check the service status with `systemctl status telegram_mirror_bot`
- Payment failures: Verify API keys for payment gateways
- High resource usage: Check the logs for potential infinite loops or memory leaks
- Connection errors: Ensure the external server is accessible

## License
This project is licensed under the MIT License - see the LICENSE file for details.
