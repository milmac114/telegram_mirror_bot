"""
Main entry point for the Telegram Mirror Bot.
"""
import sys
import os

# Add the project root directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.bot import TelegramMirrorBot
from src.logger import get_logger

logger = get_logger()

def main():
    """
    Main function to start the bot.
    """
    logger.info("Starting Telegram Mirror Bot")
    
    try:
        # Initialize and run the bot
        bot = TelegramMirrorBot()
        bot.run()
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Error running bot: {str(e)}")
        sys.exit(1)
        
if __name__ == "__main__":
    main()
