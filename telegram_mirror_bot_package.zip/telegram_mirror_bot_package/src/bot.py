"""
Main module for the Telegram Mirror Bot.
"""
import sys
import os
import asyncio

# Add the project root directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from telegram import Update, ForceReply
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext
from config import config
from src.logger import get_logger, log_exception
from src.mirror_handler import MirrorHandler
from src.error_handler import error_handler, handle_exceptions, retry
from src.notifications import send_notification

# Initialize logger
logger = get_logger()

class TelegramMirrorBot:
    """
    Main bot class that handles Telegram interactions and proxies requests to the external server.
    """
    def __init__(self):
        """
        Initialize the bot with necessary components.
        """
        self.logger = logger
        self.mirror_handler = MirrorHandler()
        
        # Check if token is available
        if not config.BOT_TOKEN:
            self.logger.error("Bot token not found. Please set BOT_TOKEN in .env file.")
            sys.exit(1)
            
        # Initialize the application
        self.application = Application.builder().token(config.BOT_TOKEN).build()
        
        # Register handlers
        self._register_handlers()
        
        self.logger.info("Bot initialized successfully")
        
    def _register_handlers(self):
        """
        Register command and message handlers.
        """
        # Command handlers
        self.application.add_handler(CommandHandler("start", self.start_command))
        self.application.add_handler(CommandHandler("help", self.help_command))
        self.application.add_handler(CommandHandler("reset", self.reset_command))
        
        # Message handlers - all non-command messages will be forwarded to the server
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
        
        # File handlers
        self.application.add_handler(MessageHandler(filters.PHOTO, self.handle_photo))
        self.application.add_handler(MessageHandler(filters.Document.ALL, self.handle_document))
        
        # Error handler
        self.application.add_error_handler(self.error_handler)
        
    @handle_exceptions
    async def start_command(self, update: Update, context: CallbackContext):
        """
        Handle the /start command.
        """
        user = update.effective_user
        self.logger.info(f"User {user.id} started the bot")
        
        welcome_message = (
            f"👋 Hello, {user.first_name}!\n\n"
            f"I'm a mirror bot that connects you to services while maintaining your privacy.\n\n"
            f"Simply send me messages, and I'll relay them to the service and return the responses.\n\n"
            f"Type /help to see available commands."
        )
        
        await update.message.reply_text(welcome_message)
        
    @handle_exceptions
    async def help_command(self, update: Update, context: CallbackContext):
        """
        Handle the /help command.
        """
        help_message = (
            "🔍 *Available Commands*\n\n"
            "/start - Start the bot\n"
            "/help - Show this help message\n"
            "/reset - Reset your conversation session\n\n"
            "You can also send messages, photos, and documents to interact with the service."
        )
        
        await update.message.reply_text(help_message, parse_mode="Markdown")
        
    @handle_exceptions
    async def reset_command(self, update: Update, context: CallbackContext):
        """
        Handle the /reset command to clear user session.
        """
        user = update.effective_user
        self.logger.info(f"User {user.id} requested session reset")
        
        # Clear the user's session
        await self.mirror_handler.session_manager.clear_session(user.id)
        
        await update.message.reply_text(
            "Your session has been reset. You can start a new conversation now."
        )
        
    @handle_exceptions
    @retry(max_retries=3, retry_delay=1.0, exceptions=(ConnectionError, TimeoutError))
    async def handle_message(self, update: Update, context: CallbackContext):
        """
        Handle user messages and forward them to the external server.
        """
        user = update.effective_user
        message_text = update.message.text
        
        self.logger.info(f"Received message from user {user.id}: {message_text[:20]}...")
        
        # Show typing indicator
        await update.effective_chat.send_chat_action("typing")
        
        try:
            # Process the message through the mirror handler
            response = await self.mirror_handler.process_user_message(user.id, message_text)
            
            # Handle different response types
            if response.get('payment_required'):
                # Send payment message with Markdown formatting
                await update.message.reply_text(
                    response.get('message', 'Payment required'),
                    parse_mode="Markdown"
                )
            elif response.get('payment_check'):
                # User is checking payment status
                payment_status = await self.mirror_handler.session_manager.get_payment_status(user.id)
                
                if payment_status.get('status') == 'completed':
                    await update.message.reply_text(
                        "Your payment has been confirmed! You can continue using the service."
                    )
                else:
                    await update.message.reply_text(
                        "Your payment is still being processed. Please wait a moment and try again."
                    )
            else:
                # Regular message response
                await update.message.reply_text(response.get('message', 'No response from server'))
                
                # If there are attachments, send them
                if response.get('attachments'):
                    for attachment in response.get('attachments'):
                        # Handle different attachment types
                        if attachment.get('type') == 'photo':
                            # In a real implementation, this would send the photo
                            await update.message.reply_text(f"[Image: {attachment.get('caption', 'Photo')}]")
                        elif attachment.get('type') == 'document':
                            # In a real implementation, this would send the document
                            await update.message.reply_text(f"[Document: {attachment.get('filename', 'File')}]")
                
        except Exception as e:
            log_exception(sys.exc_info(), {'user_id': user.id, 'message_preview': message_text[:20]})
            await update.message.reply_text(
                "Sorry, I encountered an error while processing your request. Please try again later."
            )
            
            # Send notification for serious errors
            await send_notification(
                f"Error processing message from user {user.id}: {str(e)}",
                {
                    'error_type': e.__class__.__name__,
                    'user_id': user.id,
                    'severity': 'error'
                }
            )
            
    @handle_exceptions
    @retry(max_retries=2, retry_delay=1.0, exceptions=(ConnectionError, TimeoutError))
    async def handle_photo(self, update: Update, context: CallbackContext):
        """
        Handle photo uploads from users.
        """
        user = update.effective_user
        self.logger.info(f"Received photo from user {user.id}")
        
        # Show typing indicator
        await update.effective_chat.send_chat_action("typing")
        
        try:
            # Get the photo file
            photo_file = await update.message.photo[-1].get_file()
            
            # In a real implementation, this would download the file and forward it to the server
            # For now, we'll just acknowledge receipt
            
            caption = update.message.caption or "No caption"
            
            # Process the photo through the mirror handler
            response = await self.mirror_handler.handle_file_upload(
                user.id,
                b'',  # Placeholder for file data
                f"photo_{photo_file.file_id}.jpg",
                "image/jpeg"
            )
            
            await update.message.reply_text(response.get('message', 'Photo received'))
            
        except Exception as e:
            log_exception(sys.exc_info(), {'user_id': user.id, 'file_type': 'photo'})
            await update.message.reply_text(
                "Sorry, I encountered an error while processing your photo. Please try again later."
            )
            
            # Send notification for serious errors
            await send_notification(
                f"Error processing photo from user {user.id}: {str(e)}",
                {
                    'error_type': e.__class__.__name__,
                    'user_id': user.id,
                    'severity': 'error'
                }
            )
            
    @handle_exceptions
    @retry(max_retries=2, retry_delay=1.0, exceptions=(ConnectionError, TimeoutError))
    async def handle_document(self, update: Update, context: CallbackContext):
        """
        Handle document uploads from users.
        """
        user = update.effective_user
        document = update.message.document
        self.logger.info(f"Received document from user {user.id}: {document.file_name}")
        
        # Show typing indicator
        await update.effective_chat.send_chat_action("typing")
        
        try:
            # Get the document file
            document_file = await document.get_file()
            
            # In a real implementation, this would download the file and forward it to the server
            # For now, we'll just acknowledge receipt
            
            # Process the document through the mirror handler
            response = await self.mirror_handler.handle_file_upload(
                user.id,
                b'',  # Placeholder for file data
                document.file_name,
                document.mime_type or "application/octet-stream"
            )
            
            await update.message.reply_text(response.get('message', 'Document received'))
            
        except Exception as e:
            log_exception(sys.exc_info(), {'user_id': user.id, 'file_type': 'document', 'filename': document.file_name})
            await update.message.reply_text(
                "Sorry, I encountered an error while processing your document. Please try again later."
            )
            
            # Send notification for serious errors
            await send_notification(
                f"Error processing document from user {user.id}: {str(e)}",
                {
                    'error_type': e.__class__.__name__,
                    'user_id': user.id,
                    'filename': document.file_name,
                    'severity': 'error'
                }
            )
            
    async def error_handler(self, update: object, context: CallbackContext):
        """
        Handle errors in the bot.
        """
        # Use the enhanced error handler
        await error_handler.handle_telegram_error(update, context)
        
        # Send notification for critical errors
        error = context.error
        if error and isinstance(error, (ConnectionError, TimeoutError, MemoryError, OSError)):
            await send_notification(
                f"Critical bot error: {str(error)}",
                {
                    'error_type': error.__class__.__name__,
                    'update_id': update.update_id if hasattr(update, 'update_id') else None,
                    'severity': 'critical'
                }
            )
        
    def run(self):
        """
        Run the bot.
        """
        self.logger.info("Starting bot...")
        
        try:
            # Register notification handler with error handler
            error_handler.register_notification_handler(send_notification)
            
            # Start the bot
            self.application.run_polling()
            
            self.logger.info("Bot stopped gracefully")
            
        except Exception as e:
            log_exception(sys.exc_info(), {'component': 'bot_main'})
            self.logger.critical(f"Fatal error in bot: {str(e)}")
            
            # Send critical notification
            asyncio.run(send_notification(
                f"Bot crashed with error: {str(e)}",
                {
                    'error_type': e.__class__.__name__,
                    'severity': 'critical'
                }
            ))
            
            # Re-raise to allow proper shutdown
            raise
        
if __name__ == "__main__":
    bot = TelegramMirrorBot()
    bot.run()
