"""
Secure communication module for the Telegram Mirror Bot.
"""
import json
import base64
import os
from typing import Dict, Any, Optional, Tuple, Union
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from config import config
from src.logger import get_logger

logger = get_logger()

class SecureCommunication:
    """
    Handles secure communication between the bot and the external server.
    """
    def __init__(self):
        """
        Initialize the secure communication module.
        """
        self.logger = logger
        self.keys_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'keys')
        
        # Ensure keys directory exists
        os.makedirs(self.keys_dir, exist_ok=True)
        
        # Initialize or load RSA keys
        self.private_key, self.public_key = self._load_or_generate_keys()
        
        self.logger.info("SecureCommunication initialized")
        
    def _load_or_generate_keys(self) -> Tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey]:
        """
        Load existing RSA keys or generate new ones if they don't exist.
        
        Returns:
            tuple: (private_key, public_key)
        """
        private_key_path = os.path.join(self.keys_dir, 'private_key.pem')
        public_key_path = os.path.join(self.keys_dir, 'public_key.pem')
        
        if os.path.exists(private_key_path) and os.path.exists(public_key_path):
            # Load existing keys
            try:
                with open(private_key_path, 'rb') as f:
                    private_key = serialization.load_pem_private_key(
                        f.read(),
                        password=None
                    )
                    
                with open(public_key_path, 'rb') as f:
                    public_key = serialization.load_pem_public_key(
                        f.read()
                    )
                    
                self.logger.info("Loaded existing RSA keys")
                return private_key, public_key
                
            except Exception as e:
                self.logger.error(f"Error loading RSA keys: {str(e)}")
                # Fall back to generating new keys
                
        # Generate new RSA keys
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        public_key = private_key.public_key()
        
        # Save the keys
        try:
            with open(private_key_path, 'wb') as f:
                f.write(private_key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption()
                ))
                
            with open(public_key_path, 'wb') as f:
                f.write(public_key.public_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PublicFormat.SubjectPublicKeyInfo
                ))
                
            # Set secure permissions for private key
            os.chmod(private_key_path, 0o600)
            
            self.logger.info("Generated and saved new RSA keys")
            
        except Exception as e:
            self.logger.error(f"Error saving RSA keys: {str(e)}")
            
        return private_key, public_key
        
    async def encrypt_request(self, request_data: Dict[str, Any], server_public_key: Optional[bytes] = None) -> Dict[str, Any]:
        """
        Encrypt a request to the external server.
        
        Args:
            request_data (dict): Request data to encrypt
            server_public_key (bytes, optional): Server's public key for encryption
            
        Returns:
            dict: Encrypted request data
        """
        # Convert request data to JSON string
        request_json = json.dumps(request_data)
        
        # Generate a random AES key and IV
        aes_key = os.urandom(32)  # 256-bit key
        iv = os.urandom(16)  # 128-bit IV
        
        # Encrypt the request data with AES
        encrypted_data = self._aes_encrypt(request_json.encode(), aes_key, iv)
        
        # If server public key is provided, encrypt the AES key with RSA
        if server_public_key:
            server_key = serialization.load_pem_public_key(server_public_key)
            encrypted_key = server_key.encrypt(
                aes_key,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
        else:
            # Otherwise, encrypt with our own public key (for testing)
            encrypted_key = self.public_key.encrypt(
                aes_key,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            
        # Encode binary data as base64 strings
        return {
            "encrypted_data": base64.b64encode(encrypted_data).decode(),
            "encrypted_key": base64.b64encode(encrypted_key).decode(),
            "iv": base64.b64encode(iv).decode(),
            "encryption_method": "aes-256-cbc+rsa-oaep"
        }
        
    async def decrypt_response(self, encrypted_response: Dict[str, Any]) -> Dict[str, Any]:
        """
        Decrypt a response from the external server.
        
        Args:
            encrypted_response (dict): Encrypted response data
            
        Returns:
            dict: Decrypted response data
        """
        try:
            # Extract encrypted components
            encrypted_data = base64.b64decode(encrypted_response.get("encrypted_data", ""))
            encrypted_key = base64.b64decode(encrypted_response.get("encrypted_key", ""))
            iv = base64.b64decode(encrypted_response.get("iv", ""))
            
            # Decrypt the AES key with our private key
            aes_key = self.private_key.decrypt(
                encrypted_key,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            
            # Decrypt the data with AES
            decrypted_data = self._aes_decrypt(encrypted_data, aes_key, iv)
            
            # Parse the JSON data
            return json.loads(decrypted_data.decode())
            
        except Exception as e:
            self.logger.error(f"Error decrypting response: {str(e)}")
            return {"error": "Failed to decrypt response"}
            
    def _aes_encrypt(self, data: bytes, key: bytes, iv: bytes) -> bytes:
        """
        Encrypt data with AES-256-CBC.
        
        Args:
            data (bytes): Data to encrypt
            key (bytes): AES key
            iv (bytes): Initialization vector
            
        Returns:
            bytes: Encrypted data
        """
        # Pad the data to a multiple of 16 bytes (AES block size)
        padded_data = self._pad_data(data)
        
        # Create an AES cipher
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
        encryptor = cipher.encryptor()
        
        # Encrypt the data
        encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
        
        return encrypted_data
        
    def _aes_decrypt(self, encrypted_data: bytes, key: bytes, iv: bytes) -> bytes:
        """
        Decrypt data with AES-256-CBC.
        
        Args:
            encrypted_data (bytes): Encrypted data
            key (bytes): AES key
            iv (bytes): Initialization vector
            
        Returns:
            bytes: Decrypted data
        """
        # Create an AES cipher
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
        decryptor = cipher.decryptor()
        
        # Decrypt the data
        padded_data = decryptor.update(encrypted_data) + decryptor.finalize()
        
        # Remove padding
        return self._unpad_data(padded_data)
        
    def _pad_data(self, data: bytes) -> bytes:
        """
        Pad data to a multiple of 16 bytes (PKCS#7 padding).
        
        Args:
            data (bytes): Data to pad
            
        Returns:
            bytes: Padded data
        """
        block_size = 16
        padding_length = block_size - (len(data) % block_size)
        padding = bytes([padding_length]) * padding_length
        return data + padding
        
    def _unpad_data(self, padded_data: bytes) -> bytes:
        """
        Remove PKCS#7 padding from data.
        
        Args:
            padded_data (bytes): Padded data
            
        Returns:
            bytes: Unpadded data
        """
        padding_length = padded_data[-1]
        return padded_data[:-padding_length]
        
    async def get_public_key_pem(self) -> str:
        """
        Get the bot's public key in PEM format.
        
        Returns:
            str: Public key in PEM format
        """
        public_key_pem = self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        return public_key_pem.decode()
        
    async def set_server_public_key(self, server_public_key_pem: str) -> bool:
        """
        Set the server's public key.
        
        Args:
            server_public_key_pem (str): Server's public key in PEM format
            
        Returns:
            bool: True if successful
        """
        try:
            # Save the server's public key
            server_key_path = os.path.join(self.keys_dir, 'server_public_key.pem')
            
            with open(server_key_path, 'w') as f:
                f.write(server_public_key_pem)
                
            self.logger.info("Saved server public key")
            return True
            
        except Exception as e:
            self.logger.error(f"Error saving server public key: {str(e)}")
            return False
            
    async def get_server_public_key(self) -> Optional[bytes]:
        """
        Get the server's public key if available.
        
        Returns:
            bytes: Server's public key or None if not set
        """
        server_key_path = os.path.join(self.keys_dir, 'server_public_key.pem')
        
        if os.path.exists(server_key_path):
            try:
                with open(server_key_path, 'rb') as f:
                    return f.read()
            except Exception as e:
                self.logger.error(f"Error reading server public key: {str(e)}")
                
        return None
