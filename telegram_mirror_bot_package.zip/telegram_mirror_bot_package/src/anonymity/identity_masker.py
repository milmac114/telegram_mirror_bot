"""
Identity masking module for the Telegram Mirror Bot.
"""
import re
import uuid
import hashlib
from typing import Dict, Any, Optional, Tuple
from config import config
from src.logger import get_logger
from src.encryption import encrypt_data, decrypt_data

logger = get_logger()

class IdentityMasker:
    """
    Handles masking of server identity and user information.
    """
    def __init__(self):
        """
        Initialize the identity masker.
        """
        self.logger = logger
        self.identity_map = {}  # In a production environment, this would be a database
        self.logger.info("IdentityMasker initialized")
        
    async def mask_server_info(self, response_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Mask any server identity information in the response.
        
        Args:
            response_data (dict): Response data from the server
            
        Returns:
            dict: Masked response data
        """
        # Create a copy of the response data to avoid modifying the original
        masked_data = response_data.copy()
        
        # Mask server information in the message
        if 'message' in masked_data and isinstance(masked_data['message'], str):
            masked_data['message'] = await self._mask_identifiers_in_text(masked_data['message'])
            
        # Mask server information in attachments
        if 'attachments' in masked_data and isinstance(masked_data['attachments'], list):
            for i, attachment in enumerate(masked_data['attachments']):
                if 'caption' in attachment:
                    masked_data['attachments'][i]['caption'] = await self._mask_identifiers_in_text(attachment['caption'])
                if 'filename' in attachment:
                    masked_data['attachments'][i]['filename'] = await self._mask_filename(attachment['filename'])
                    
        # Remove any server-specific headers or metadata
        if 'headers' in masked_data:
            masked_data.pop('headers')
            
        # Remove any server URLs or identifiers
        if 'server_url' in masked_data:
            masked_data.pop('server_url')
            
        # Remove any server API keys or credentials
        if 'api_key' in masked_data:
            masked_data.pop('api_key')
            
        return masked_data
        
    async def mask_user_info(self, user_id: int, user_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Mask user identity information before sending to the server.
        
        Args:
            user_id (int): Telegram user ID
            user_data (dict): User data to mask
            
        Returns:
            dict: Masked user data
        """
        # Create a copy of the user data to avoid modifying the original
        masked_data = user_data.copy()
        
        # Generate a unique anonymous ID for this user if not exists
        anonymous_id = await self._get_anonymous_id(user_id)
        
        # Replace user ID with anonymous ID
        if 'user_id' in masked_data:
            masked_data['user_id'] = anonymous_id
            
        # Replace username if present
        if 'username' in masked_data:
            masked_data['username'] = f"user_{anonymous_id[:8]}"
            
        # Replace any personal information
        if 'first_name' in masked_data:
            masked_data['first_name'] = "Anonymous"
            
        if 'last_name' in masked_data:
            masked_data['last_name'] = "User"
            
        # Mask any phone numbers in the message
        if 'message' in masked_data and isinstance(masked_data['message'], str):
            masked_data['message'] = await self._mask_personal_info_in_text(masked_data['message'])
            
        return masked_data
        
    async def _mask_identifiers_in_text(self, text: str) -> str:
        """
        Mask server identifiers in text.
        
        Args:
            text (str): Text to mask
            
        Returns:
            str: Masked text
        """
        if not text:
            return text
            
        # Mask URLs that might reveal server identity
        url_pattern = r'https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+'
        text = re.sub(url_pattern, '[Secure Link]', text)
        
        # Mask email addresses
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        text = re.sub(email_pattern, '[Secure Email]', text)
        
        # Mask IP addresses
        ip_pattern = r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b'
        text = re.sub(ip_pattern, '[Secure IP]', text)
        
        # Mask any server name mentions
        if config.SERVER_URL:
            server_domain = config.SERVER_URL.split('//')[1].split('/')[0]
            text = text.replace(server_domain, '[Service Provider]')
            
        return text
        
    async def _mask_personal_info_in_text(self, text: str) -> str:
        """
        Mask personal information in text.
        
        Args:
            text (str): Text to mask
            
        Returns:
            str: Masked text
        """
        if not text:
            return text
            
        # Mask phone numbers
        phone_pattern = r'\b(?:\+\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b'
        text = re.sub(phone_pattern, '[Phone Number]', text)
        
        # Mask credit card numbers
        cc_pattern = r'\b(?:\d{4}[-.\s]?){3}\d{4}\b'
        text = re.sub(cc_pattern, '[Credit Card]', text)
        
        # Mask social security numbers (US)
        ssn_pattern = r'\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b'
        text = re.sub(ssn_pattern, '[ID Number]', text)
        
        return text
        
    async def _mask_filename(self, filename: str) -> str:
        """
        Mask a filename to remove server-specific information.
        
        Args:
            filename (str): Original filename
            
        Returns:
            str: Masked filename
        """
        if not filename:
            return filename
            
        # Get file extension
        parts = filename.split('.')
        extension = parts[-1] if len(parts) > 1 else ''
        
        # Generate a random filename
        random_name = str(uuid.uuid4())[:8]
        
        if extension:
            return f"file_{random_name}.{extension}"
        else:
            return f"file_{random_name}"
            
    async def _get_anonymous_id(self, user_id: int) -> str:
        """
        Get or create an anonymous ID for a user.
        
        Args:
            user_id (int): Telegram user ID
            
        Returns:
            str: Anonymous ID
        """
        user_id_str = str(user_id)
        
        if user_id_str not in self.identity_map:
            # Create a hash of the user ID with a salt
            salt = config.ENCRYPTION_KEY or "telegram_mirror_bot"
            hash_input = f"{user_id_str}:{salt}"
            anonymous_id = hashlib.sha256(hash_input.encode()).hexdigest()
            
            # Store the mapping
            self.identity_map[user_id_str] = anonymous_id
            
        return self.identity_map[user_id_str]
        
    async def get_real_user_id(self, anonymous_id: str) -> Optional[int]:
        """
        Get the real user ID from an anonymous ID.
        
        Args:
            anonymous_id (str): Anonymous ID
            
        Returns:
            int: Real user ID or None if not found
        """
        # In a production environment, this would query a database
        
        for user_id, anon_id in self.identity_map.items():
            if anon_id == anonymous_id:
                return int(user_id)
                
        return None
