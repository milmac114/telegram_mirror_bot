"""
Enhanced payment handler module for the Telegram Mirror Bot.
"""
import json
import uuid
from datetime import datetime
from typing import Dict, Any, Optional, List
from config import config
from src.logger import get_logger
from src.payment.stripe_gateway import StripePaymentGateway
from src.payment.coinbase_gateway import CoinbasePaymentGateway
from src.payment.direct_crypto import DirectCryptoWallet
from src.payment.payment_processor import PaymentProcessor

logger = get_logger()

class PaymentHandler:
    """
    Handles payment processing with multiple payment methods.
    """
    def __init__(self):
        """
        Initialize payment handler with configured payment providers.
        """
        self.logger = logger
        
        # Initialize payment gateways
        self.stripe_gateway = StripePaymentGateway()
        self.coinbase_gateway = CoinbasePaymentGateway()
        self.direct_crypto = DirectCryptoWallet()
        self.payment_processor = PaymentProcessor()
        
        # Track available payment methods
        self.available_methods = []
        
        if self.stripe_gateway.enabled:
            self.available_methods.append("stripe")
            
        if self.coinbase_gateway.enabled:
            self.available_methods.append("coinbase")
            
        if self.direct_crypto.enabled:
            self.available_methods.append("direct_crypto")
            
        self.logger.info(f"PaymentHandler initialized with methods: {', '.join(self.available_methods)}")
        
    async def create_payment_request(self, user_id: int, amount: float, currency: str = "USD", 
                                    description: str = "Service payment") -> str:
        """
        Create a payment request for the user.
        
        Args:
            user_id (int): Telegram user ID
            amount (float): Payment amount
            currency (str): Currency code (default: USD)
            description (str): Payment description
            
        Returns:
            str: Payment message with instructions
        """
        self.logger.info(f"Creating payment request for user {user_id}: {amount} {currency}")
        
        # Generate unique payment ID
        payment_id = str(uuid.uuid4())
        
        # Calculate commission
        commission_amount, server_amount = await self.payment_processor.calculate_commission(amount, currency)
        
        # Store payment information (in a real implementation, this would go to a database)
        payment_info = {
            "payment_id": payment_id,
            "user_id": user_id,
            "amount": float(amount),
            "currency": currency,
            "commission_amount": float(commission_amount),
            "server_amount": float(server_amount),
            "description": description,
            "status": "pending",
            "created_at": datetime.utcnow().isoformat(),
            "completed_at": None
        }
        
        # In a real implementation, save payment_info to database
        
        # Create payment message with available payment methods
        payment_message = (
            f"💰 *Payment Required*\n\n"
            f"Amount: {amount} {currency}\n"
            f"Description: {description}\n\n"
            f"*Payment Methods:*\n\n"
        )
        
        # Add Stripe payment option if enabled
        if "stripe" in self.available_methods:
            metadata = {"user_id": str(user_id), "commission_percentage": str(config.COMMISSION_PERCENTAGE)}
            stripe_link = await self.stripe_gateway.create_payment_link(
                payment_id, amount, currency, description, metadata
            )
            if stripe_link:
                payment_message += f"*Credit Card Payment:*\n[Pay with Card]({stripe_link})\n\n"
            
        # Add Cryptocurrency payment option if enabled
        if "coinbase" in self.available_methods:
            metadata = {"user_id": str(user_id), "commission_percentage": str(config.COMMISSION_PERCENTAGE)}
            crypto_link = await self.coinbase_gateway.create_payment_link(
                payment_id, amount, currency, description, metadata
            )
            if crypto_link:
                payment_message += f"*Cryptocurrency Payment:*\n[Pay with Crypto]({crypto_link})\n\n"
            
        # Add direct wallet transfer option
        if "direct_crypto" in self.available_methods:
            direct_instructions = await self.direct_crypto.generate_payment_instructions(
                payment_id, amount, currency, description
            )
            payment_message += f"{direct_instructions}\n\n"
            
        payment_message += (
            f"_Payment ID: {payment_id}_\n\n"
            f"After completing payment, the service will continue automatically."
        )
        
        return payment_message
        
    async def process_payment_webhook(self, provider: str, payload: Dict[str, Any]) -> bool:
        """
        Process payment webhook from payment providers.
        
        Args:
            provider (str): Payment provider name ('stripe' or 'coinbase')
            payload (dict): Webhook payload
            
        Returns:
            bool: True if payment was successfully processed
        """
        self.logger.info(f"Processing {provider} webhook")
        
        try:
            payment_data = None
            
            if provider == 'stripe' and "stripe" in self.available_methods:
                payment_data = await self.stripe_gateway.process_webhook(payload)
            elif provider == 'coinbase' and "coinbase" in self.available_methods:
                payment_data = await self.coinbase_gateway.process_webhook(payload)
            else:
                self.logger.error(f"Unknown or disabled payment provider: {provider}")
                return False
                
            if payment_data and payment_data.get('success'):
                # Record the transaction
                transaction_id = await self.payment_processor.record_transaction(payment_data)
                
                # Forward payment to server owner
                await self.payment_processor.forward_funds_to_server_owner(transaction_id)
                
                self.logger.info(f"Payment {payment_data.get('payment_id')} processed successfully")
                return True
                
            return False
            
        except Exception as e:
            self.logger.error(f"Error processing {provider} webhook: {str(e)}")
            return False
            
    async def verify_direct_payment(self, payment_id: str, transaction_hash: Optional[str] = None) -> Dict[str, Any]:
        """
        Verify a direct cryptocurrency payment.
        
        Args:
            payment_id (str): Payment ID to verify
            transaction_hash (str, optional): Transaction hash for verification
            
        Returns:
            dict: Verification result
        """
        if "direct_crypto" not in self.available_methods:
            return {"verified": False, "error": "Direct cryptocurrency payments are not enabled"}
            
        return await self.direct_crypto.verify_payment(payment_id, transaction_hash)
        
    async def manual_verify_payment(self, payment_id: str, admin_id: int, 
                                  amount: float, currency: str) -> bool:
        """
        Manually verify a payment (for admin use).
        
        Args:
            payment_id (str): Payment ID to verify
            admin_id (int): Admin user ID performing verification
            amount (float): Payment amount
            currency (str): Currency code
            
        Returns:
            bool: True if payment was successfully verified
        """
        if "direct_crypto" not in self.available_methods:
            return False
            
        payment_data = await self.direct_crypto.manual_verify_payment(
            payment_id, admin_id, amount, currency
        )
        
        if payment_data and payment_data.get('success'):
            # Record the transaction
            transaction_id = await self.payment_processor.record_transaction(payment_data)
            
            # Forward payment to server owner
            await self.payment_processor.forward_funds_to_server_owner(transaction_id)
            
            self.logger.info(f"Payment {payment_id} manually verified by admin {admin_id}")
            return True
            
        return False
        
    async def get_payment_methods(self) -> List[str]:
        """
        Get list of available payment methods.
        
        Returns:
            list: Available payment methods
        """
        return self.available_methods
        
    async def get_payment_stats(self) -> Dict[str, Any]:
        """
        Get payment statistics.
        
        Returns:
            dict: Payment statistics
        """
        # In a real implementation, this would query a database
        # For now, we'll just return a placeholder
        
        return {
            "total_payments": 0,
            "total_amount": 0,
            "total_commission": 0,
            "methods": {
                "stripe": 0,
                "coinbase": 0,
                "direct_crypto": 0
            }
        }
