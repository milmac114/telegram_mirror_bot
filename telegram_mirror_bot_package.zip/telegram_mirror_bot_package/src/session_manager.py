"""
Session management module for the Telegram Mirror Bot.
"""
import json
import time
from typing import Dict, Any, Optional
from config import config
from src.logger import get_logger

logger = get_logger()

class SessionManager:
    """
    Manages user sessions for the Telegram Mirror Bot.
    """
    def __init__(self):
        """
        Initialize the session manager.
        """
        self.logger = logger
        self.sessions = {}  # In a production environment, this would be a database
        self.logger.info("SessionManager initialized")
        
    async def get_session(self, user_id: int) -> Dict[str, Any]:
        """
        Get or create a session for a user.
        
        Args:
            user_id (int): Telegram user ID
            
        Returns:
            dict: Session data
        """
        session_id = f"tg_{user_id}"
        
        if session_id not in self.sessions:
            # Create a new session
            self.sessions[session_id] = {
                "session_id": session_id,
                "user_id": user_id,
                "created_at": time.time(),
                "last_activity": time.time(),
                "context": {},
                "payment_status": None,
                "active_payment_id": None
            }
            self.logger.info(f"Created new session for user {user_id}")
        else:
            # Update last activity
            self.sessions[session_id]["last_activity"] = time.time()
            
        return self.sessions[session_id]
        
    async def update_session(self, user_id: int, data: Dict[str, Any]) -> None:
        """
        Update session data for a user.
        
        Args:
            user_id (int): Telegram user ID
            data (dict): Data to update in the session
        """
        session_id = f"tg_{user_id}"
        
        if session_id in self.sessions:
            self.sessions[session_id].update(data)
            self.sessions[session_id]["last_activity"] = time.time()
            self.logger.debug(f"Updated session for user {user_id}")
        else:
            self.logger.warning(f"Attempted to update non-existent session for user {user_id}")
            
    async def clear_session(self, user_id: int) -> None:
        """
        Clear a user's session.
        
        Args:
            user_id (int): Telegram user ID
        """
        session_id = f"tg_{user_id}"
        
        if session_id in self.sessions:
            del self.sessions[session_id]
            self.logger.info(f"Cleared session for user {user_id}")
            
    async def get_session_context(self, user_id: int) -> Dict[str, Any]:
        """
        Get the context data for a user's session.
        
        Args:
            user_id (int): Telegram user ID
            
        Returns:
            dict: Session context data
        """
        session = await self.get_session(user_id)
        return session.get("context", {})
        
    async def update_session_context(self, user_id: int, context_data: Dict[str, Any]) -> None:
        """
        Update the context data for a user's session.
        
        Args:
            user_id (int): Telegram user ID
            context_data (dict): Context data to update
        """
        session = await self.get_session(user_id)
        
        if "context" not in session:
            session["context"] = {}
            
        session["context"].update(context_data)
        await self.update_session(user_id, {"context": session["context"]})
        
    async def set_payment_status(self, user_id: int, payment_id: Optional[str], status: Optional[str]) -> None:
        """
        Set the payment status for a user's session.
        
        Args:
            user_id (int): Telegram user ID
            payment_id (str): Payment ID or None
            status (str): Payment status or None
        """
        await self.update_session(user_id, {
            "payment_status": status,
            "active_payment_id": payment_id
        })
        
    async def get_payment_status(self, user_id: int) -> Dict[str, Any]:
        """
        Get the payment status for a user's session.
        
        Args:
            user_id (int): Telegram user ID
            
        Returns:
            dict: Payment status information
        """
        session = await self.get_session(user_id)
        return {
            "status": session.get("payment_status"),
            "payment_id": session.get("active_payment_id")
        }
        
    async def cleanup_old_sessions(self, max_age_seconds: int = 86400) -> int:
        """
        Clean up old sessions that have been inactive.
        
        Args:
            max_age_seconds (int): Maximum age in seconds (default: 24 hours)
            
        Returns:
            int: Number of sessions cleaned up
        """
        current_time = time.time()
        sessions_to_remove = []
        
        for session_id, session_data in self.sessions.items():
            last_activity = session_data.get("last_activity", 0)
            if current_time - last_activity > max_age_seconds:
                sessions_to_remove.append(session_id)
                
        for session_id in sessions_to_remove:
            del self.sessions[session_id]
            
        if sessions_to_remove:
            self.logger.info(f"Cleaned up {len(sessions_to_remove)} old sessions")
            
        return len(sessions_to_remove)
