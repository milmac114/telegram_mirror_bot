"""
User management module for the Telegram Mirror Bot admin panel.
"""
import time
from typing import Dict, Any, List, Optional
from config import config
from src.logger import get_logger

logger = get_logger()

class UserManager:
    """
    Handles user management for the admin panel.
    """
    def __init__(self):
        """
        Initialize the user management module.
        """
        self.logger = logger
        
        # In a production environment, this would use a database
        # For now, we'll use an in-memory store
        self.users = {}
        
        self.logger.info("UserManager initialized")
        
    async def register_user(self, user_id: int, user_data: Dict[str, Any]) -> bool:
        """
        Register a new user or update existing user data.
        
        Args:
            user_id (int): Telegram user ID
            user_data (dict): User data to store
            
        Returns:
            bool: True if successful
        """
        user_id_str = str(user_id)
        
        # Add timestamp if not present
        if 'registered_at' not in user_data:
            user_data['registered_at'] = time.time()
            
        # Update last activity
        user_data['last_activity'] = time.time()
        
        # Store user data
        self.users[user_id_str] = user_data
        
        self.logger.info(f"Registered user {user_id}")
        
        return True
        
    async def get_user(self, user_id: int) -> Optional[Dict[str, Any]]:
        """
        Get user data by ID.
        
        Args:
            user_id (int): Telegram user ID
            
        Returns:
            dict: User data or None if not found
        """
        user_id_str = str(user_id)
        return self.users.get(user_id_str)
        
    async def update_user_activity(self, user_id: int) -> bool:
        """
        Update user's last activity timestamp.
        
        Args:
            user_id (int): Telegram user ID
            
        Returns:
            bool: True if successful
        """
        user_id_str = str(user_id)
        
        if user_id_str in self.users:
            self.users[user_id_str]['last_activity'] = time.time()
            return True
            
        return False
        
    async def get_users(self, 
                      active_since: Optional[float] = None,
                      limit: int = 100,
                      offset: int = 0) -> List[Dict[str, Any]]:
        """
        Get users with optional filtering.
        
        Args:
            active_since (float, optional): Filter users active since timestamp
            limit (int): Maximum number of users to return
            offset (int): Offset for pagination
            
        Returns:
            list: List of user data
        """
        # Convert users dict to list
        users_list = list(self.users.values())
        
        # Apply filters
        if active_since is not None:
            users_list = [user for user in users_list 
                        if user.get('last_activity', 0) >= active_since]
                        
        # Sort by last activity (most recent first)
        users_list.sort(key=lambda user: user.get('last_activity', 0), reverse=True)
        
        # Apply pagination
        paginated_users = users_list[offset:offset + limit]
        
        return paginated_users
        
    async def get_user_stats(self) -> Dict[str, Any]:
        """
        Get user statistics.
        
        Returns:
            dict: User statistics
        """
        total_users = len(self.users)
        
        # Count active users in last day
        day_ago = time.time() - 86400
        active_day = len([user for user in self.users.values() 
                        if user.get('last_activity', 0) >= day_ago])
                        
        # Count active users in last week
        week_ago = time.time() - (7 * 86400)
        active_week = len([user for user in self.users.values() 
                         if user.get('last_activity', 0) >= week_ago])
                         
        # Count active users in last month
        month_ago = time.time() - (30 * 86400)
        active_month = len([user for user in self.users.values() 
                          if user.get('last_activity', 0) >= month_ago])
                          
        # Count new users in last month
        new_month = len([user for user in self.users.values() 
                       if user.get('registered_at', 0) >= month_ago])
        
        return {
            'total_users': total_users,
            'active_day': active_day,
            'active_week': active_week,
            'active_month': active_month,
            'new_month': new_month
        }
        
    async def block_user(self, user_id: int, reason: str = "") -> bool:
        """
        Block a user from using the bot.
        
        Args:
            user_id (int): Telegram user ID to block
            reason (str, optional): Reason for blocking
            
        Returns:
            bool: True if successful
        """
        user_id_str = str(user_id)
        
        if user_id_str in self.users:
            self.users[user_id_str]['blocked'] = True
            self.users[user_id_str]['blocked_at'] = time.time()
            self.users[user_id_str]['block_reason'] = reason
            
            self.logger.info(f"Blocked user {user_id}: {reason}")
            return True
            
        return False
        
    async def unblock_user(self, user_id: int) -> bool:
        """
        Unblock a previously blocked user.
        
        Args:
            user_id (int): Telegram user ID to unblock
            
        Returns:
            bool: True if successful
        """
        user_id_str = str(user_id)
        
        if user_id_str in self.users:
            self.users[user_id_str]['blocked'] = False
            self.users[user_id_str]['unblocked_at'] = time.time()
            
            self.logger.info(f"Unblocked user {user_id}")
            return True
            
        return False
        
    async def is_user_blocked(self, user_id: int) -> bool:
        """
        Check if a user is blocked.
        
        Args:
            user_id (int): Telegram user ID to check
            
        Returns:
            bool: True if user is blocked
        """
        user_id_str = str(user_id)
        
        if user_id_str in self.users:
            return self.users[user_id_str].get('blocked', False)
            
        return False
        
    async def get_blocked_users(self) -> List[Dict[str, Any]]:
        """
        Get all blocked users.
        
        Returns:
            list: List of blocked user data
        """
        return [user for user in self.users.values() if user.get('blocked', False)]
