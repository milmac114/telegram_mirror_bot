"""
Admin authentication module for the Telegram Mirror Bot.
"""
import os
import json
import time
import hashlib
import secrets
from typing import Dict, Any, Optional, List
from config import config
from src.logger import get_logger

logger = get_logger()

class AdminAuth:
    """
    Handles authentication for the admin panel.
    """
    def __init__(self):
        """
        Initialize the admin authentication module.
        """
        self.logger = logger
        self.admin_usernames = config.ADMIN_USERNAMES
        self.admin_panel_username = config.ADMIN_PANEL_USERNAME
        self.admin_panel_password = config.ADMIN_PANEL_PASSWORD
        
        # Directory for storing session data
        self.sessions_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'sessions')
        os.makedirs(self.sessions_dir, exist_ok=True)
        
        # Active sessions
        self.active_sessions = {}
        
        self.logger.info("AdminAuth initialized")
        
    def is_telegram_admin(self, username: str) -> bool:
        """
        Check if a Telegram username is an admin.
        
        Args:
            username (str): Telegram username to check
            
        Returns:
            bool: True if the username is an admin
        """
        return username in self.admin_usernames
        
    def verify_credentials(self, username: str, password: str) -> bool:
        """
        Verify admin panel login credentials.
        
        Args:
            username (str): Admin username
            password (str): Admin password
            
        Returns:
            bool: True if credentials are valid
        """
        return username == self.admin_panel_username and password == self.admin_panel_password
        
    def create_session(self, username: str) -> str:
        """
        Create a new admin session.
        
        Args:
            username (str): Admin username
            
        Returns:
            str: Session token
        """
        # Generate a secure random token
        token = secrets.token_hex(32)
        
        # Create session data
        session_data = {
            "username": username,
            "created_at": time.time(),
            "last_activity": time.time(),
            "ip_address": None,  # Would be set when used in a web context
            "user_agent": None   # Would be set when used in a web context
        }
        
        # Store session data
        self.active_sessions[token] = session_data
        
        # Save session to file
        session_file = os.path.join(self.sessions_dir, f"{token}.json")
        with open(session_file, 'w') as f:
            json.dump(session_data, f)
            
        self.logger.info(f"Created admin session for {username}")
        
        return token
        
    def validate_session(self, token: str) -> bool:
        """
        Validate an admin session token.
        
        Args:
            token (str): Session token to validate
            
        Returns:
            bool: True if the session is valid
        """
        # Check if token is in active sessions
        if token in self.active_sessions:
            session_data = self.active_sessions[token]
            
            # Check if session has expired (24 hours)
            if time.time() - session_data["created_at"] > 86400:
                self.invalidate_session(token)
                return False
                
            # Update last activity
            session_data["last_activity"] = time.time()
            self.active_sessions[token] = session_data
            
            # Update session file
            session_file = os.path.join(self.sessions_dir, f"{token}.json")
            with open(session_file, 'w') as f:
                json.dump(session_data, f)
                
            return True
            
        # Check if token exists as a file
        session_file = os.path.join(self.sessions_dir, f"{token}.json")
        if os.path.exists(session_file):
            try:
                with open(session_file, 'r') as f:
                    session_data = json.load(f)
                    
                # Check if session has expired (24 hours)
                if time.time() - session_data["created_at"] > 86400:
                    self.invalidate_session(token)
                    return False
                    
                # Add to active sessions
                session_data["last_activity"] = time.time()
                self.active_sessions[token] = session_data
                
                # Update session file
                with open(session_file, 'w') as f:
                    json.dump(session_data, f)
                    
                return True
                
            except Exception as e:
                self.logger.error(f"Error validating session from file: {str(e)}")
                
        return False
        
    def invalidate_session(self, token: str) -> bool:
        """
        Invalidate an admin session.
        
        Args:
            token (str): Session token to invalidate
            
        Returns:
            bool: True if the session was invalidated
        """
        # Remove from active sessions
        if token in self.active_sessions:
            del self.active_sessions[token]
            
        # Remove session file
        session_file = os.path.join(self.sessions_dir, f"{token}.json")
        if os.path.exists(session_file):
            try:
                os.remove(session_file)
            except Exception as e:
                self.logger.error(f"Error removing session file: {str(e)}")
                
        self.logger.info(f"Invalidated admin session {token[:8]}...")
        
        return True
        
    def cleanup_expired_sessions(self) -> int:
        """
        Clean up expired admin sessions.
        
        Returns:
            int: Number of sessions cleaned up
        """
        count = 0
        current_time = time.time()
        
        # Check active sessions
        tokens_to_remove = []
        for token, session_data in self.active_sessions.items():
            if current_time - session_data["created_at"] > 86400:
                tokens_to_remove.append(token)
                
        for token in tokens_to_remove:
            self.invalidate_session(token)
            count += 1
            
        # Check session files
        for filename in os.listdir(self.sessions_dir):
            if filename.endswith('.json'):
                session_file = os.path.join(self.sessions_dir, filename)
                try:
                    with open(session_file, 'r') as f:
                        session_data = json.load(f)
                        
                    if current_time - session_data["created_at"] > 86400:
                        os.remove(session_file)
                        count += 1
                        
                except Exception as e:
                    self.logger.error(f"Error checking session file {filename}: {str(e)}")
                    
        self.logger.info(f"Cleaned up {count} expired admin sessions")
        
        return count
