"""
Settings management module for the Telegram Mirror Bot admin panel.
"""
import os
import json
import time
from typing import Dict, Any, List, Optional, Union
from config import config
from src.logger import get_logger

logger = get_logger()

class SettingsManager:
    """
    Handles settings management for the admin panel.
    """
    def __init__(self):
        """
        Initialize the settings management module.
        """
        self.logger = logger
        
        # Directory for storing settings
        self.settings_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'config')
        self.settings_file = os.path.join(self.settings_dir, 'settings.json')
        
        # Default settings
        self.default_settings = {
            "commission_percentage": config.COMMISSION_PERCENTAGE,
            "payment_methods": {
                "stripe": config.STRIPE_API_KEY is not None,
                "coinbase": config.COINBASE_API_KEY is not None,
                "direct_crypto": config.PAYMENT_WALLET_ADDRESS is not None
            },
            "admin_usernames": config.ADMIN_USERNAMES,
            "log_level": config.LOG_LEVEL,
            "server_timeout": config.SERVER_TIMEOUT,
            "anonymity": {
                "mask_server_identity": True,
                "encrypt_communications": True,
                "mask_user_info": True
            },
            "auto_forward_payments": True,
            "session_timeout_hours": 24,
            "last_updated": time.time()
        }
        
        # Load or create settings
        self.settings = self._load_settings()
        
        self.logger.info("SettingsManager initialized")
        
    def _load_settings(self) -> Dict[str, Any]:
        """
        Load settings from file or create default settings.
        
        Returns:
            dict: Settings data
        """
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, 'r') as f:
                    settings = json.load(f)
                    
                self.logger.info("Loaded settings from file")
                return settings
                
            except Exception as e:
                self.logger.error(f"Error loading settings: {str(e)}")
                
        # Create default settings
        self._save_settings(self.default_settings)
        return self.default_settings
        
    def _save_settings(self, settings: Dict[str, Any]) -> bool:
        """
        Save settings to file.
        
        Args:
            settings (dict): Settings data to save
            
        Returns:
            bool: True if successful
        """
        try:
            # Ensure settings directory exists
            os.makedirs(self.settings_dir, exist_ok=True)
            
            # Update last_updated timestamp
            settings['last_updated'] = time.time()
            
            # Save settings to file
            with open(self.settings_file, 'w') as f:
                json.dump(settings, f, indent=2)
                
            self.logger.info("Saved settings to file")
            return True
            
        except Exception as e:
            self.logger.error(f"Error saving settings: {str(e)}")
            return False
            
    async def get_settings(self) -> Dict[str, Any]:
        """
        Get current settings.
        
        Returns:
            dict: Current settings
        """
        return self.settings
        
    async def update_settings(self, new_settings: Dict[str, Any]) -> bool:
        """
        Update settings.
        
        Args:
            new_settings (dict): New settings data
            
        Returns:
            bool: True if successful
        """
        # Merge new settings with existing settings
        for key, value in new_settings.items():
            if key in self.settings:
                if isinstance(value, dict) and isinstance(self.settings[key], dict):
                    # Merge nested dictionaries
                    self.settings[key].update(value)
                else:
                    # Replace value
                    self.settings[key] = value
                    
        # Save updated settings
        success = self._save_settings(self.settings)
        
        if success:
            self.logger.info("Updated settings")
            
        return success
        
    async def reset_settings(self) -> bool:
        """
        Reset settings to defaults.
        
        Returns:
            bool: True if successful
        """
        self.settings = self.default_settings.copy()
        success = self._save_settings(self.settings)
        
        if success:
            self.logger.info("Reset settings to defaults")
            
        return success
        
    async def get_setting(self, key: str, default: Any = None) -> Any:
        """
        Get a specific setting value.
        
        Args:
            key (str): Setting key
            default (any, optional): Default value if key not found
            
        Returns:
            any: Setting value
        """
        # Handle nested keys with dot notation
        if '.' in key:
            parts = key.split('.')
            value = self.settings
            for part in parts:
                if isinstance(value, dict) and part in value:
                    value = value[part]
                else:
                    return default
            return value
            
        return self.settings.get(key, default)
        
    async def set_setting(self, key: str, value: Any) -> bool:
        """
        Set a specific setting value.
        
        Args:
            key (str): Setting key
            value (any): Setting value
            
        Returns:
            bool: True if successful
        """
        # Handle nested keys with dot notation
        if '.' in key:
            parts = key.split('.')
            target = self.settings
            for part in parts[:-1]:
                if part not in target:
                    target[part] = {}
                target = target[part]
            target[parts[-1]] = value
        else:
            self.settings[key] = value
            
        # Save updated settings
        success = self._save_settings(self.settings)
        
        if success:
            self.logger.info(f"Updated setting: {key}")
            
        return success
        
    async def export_settings(self, format: str = 'json') -> str:
        """
        Export settings to a specific format.
        
        Args:
            format (str): Export format ('json')
            
        Returns:
            str: Exported settings
        """
        if format == 'json':
            return json.dumps(self.settings, indent=2)
        else:
            raise ValueError(f"Unsupported export format: {format}")
            
    async def import_settings(self, settings_data: str, format: str = 'json') -> bool:
        """
        Import settings from a specific format.
        
        Args:
            settings_data (str): Settings data to import
            format (str): Import format ('json')
            
        Returns:
            bool: True if successful
        """
        try:
            if format == 'json':
                new_settings = json.loads(settings_data)
                return await self.update_settings(new_settings)
            else:
                raise ValueError(f"Unsupported import format: {format}")
                
        except Exception as e:
            self.logger.error(f"Error importing settings: {str(e)}")
            return False
