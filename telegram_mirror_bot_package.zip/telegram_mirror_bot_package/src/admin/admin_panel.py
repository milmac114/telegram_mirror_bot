"""
Admin panel web interface for the Telegram Mirror Bot.
"""
from flask import Flask, request, jsonify, render_template, redirect, url_for, session
import os
import json
import time
from functools import wraps
from config import config
from src.logger import get_logger
from src.admin.admin_auth import AdminAuth
from src.admin.transaction_monitor import TransactionMonitor
from src.admin.settings_manager import SettingsManager
from src.admin.user_manager import UserManager

logger = get_logger()

class AdminPanel:
    """
    Web interface for the Telegram Mirror Bot admin panel.
    """
    def __init__(self):
        """
        Initialize the admin panel web interface.
        """
        self.logger = logger
        self.admin_auth = AdminAuth()
        self.transaction_monitor = TransactionMonitor()
        self.settings_manager = SettingsManager()
        self.user_manager = UserManager()
        
        # Create Flask app
        self.app = Flask(__name__)
        self.app.secret_key = config.ENCRYPTION_KEY or os.urandom(24)
        
        # Register routes
        self._register_routes()
        
        self.logger.info("AdminPanel initialized")
        
    def _register_routes(self):
        """
        Register routes for the admin panel.
        """
        # Authentication routes
        self.app.route('/login', methods=['GET', 'POST'])(self.login)
        self.app.route('/logout')(self.logout)
        
        # Dashboard route
        self.app.route('/')(self.require_auth(self.dashboard))
        self.app.route('/dashboard')(self.require_auth(self.dashboard))
        
        # Transaction routes
        self.app.route('/transactions')(self.require_auth(self.transactions))
        self.app.route('/transactions/<transaction_id>')(self.require_auth(self.transaction_detail))
        self.app.route('/transactions/export')(self.require_auth(self.export_transactions))
        
        # User routes
        self.app.route('/users')(self.require_auth(self.users))
        self.app.route('/users/<user_id>')(self.require_auth(self.user_detail))
        self.app.route('/users/<user_id>/block', methods=['POST'])(self.require_auth(self.block_user))
        self.app.route('/users/<user_id>/unblock', methods=['POST'])(self.require_auth(self.unblock_user))
        
        # Settings routes
        self.app.route('/settings', methods=['GET', 'POST'])(self.require_auth(self.settings))
        self.app.route('/settings/export')(self.require_auth(self.export_settings))
        self.app.route('/settings/import', methods=['POST'])(self.require_auth(self.import_settings))
        self.app.route('/settings/reset', methods=['POST'])(self.require_auth(self.reset_settings))
        
        # API routes
        self.app.route('/api/stats')(self.require_auth_api(self.api_stats))
        self.app.route('/api/transactions')(self.require_auth_api(self.api_transactions))
        self.app.route('/api/users')(self.require_auth_api(self.api_users))
        
    def require_auth(self, f):
        """
        Decorator to require authentication for routes.
        """
        @wraps(f)
        def decorated(*args, **kwargs):
            if 'token' not in session:
                return redirect(url_for('login'))
                
            if not self.admin_auth.validate_session(session['token']):
                session.pop('token', None)
                return redirect(url_for('login'))
                
            return f(*args, **kwargs)
        return decorated
        
    def require_auth_api(self, f):
        """
        Decorator to require authentication for API routes.
        """
        @wraps(f)
        def decorated(*args, **kwargs):
            token = request.headers.get('Authorization')
            
            if not token or not token.startswith('Bearer '):
                return jsonify({'error': 'Unauthorized'}), 401
                
            token = token.split(' ')[1]
            
            if not self.admin_auth.validate_session(token):
                return jsonify({'error': 'Unauthorized'}), 401
                
            return f(*args, **kwargs)
        return decorated
        
    def login(self):
        """
        Handle login requests.
        """
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            
            if self.admin_auth.verify_credentials(username, password):
                token = self.admin_auth.create_session(username)
                session['token'] = token
                return redirect(url_for('dashboard'))
                
            return render_template('login.html', error='Invalid credentials')
            
        return render_template('login.html')
        
    def logout(self):
        """
        Handle logout requests.
        """
        if 'token' in session:
            self.admin_auth.invalidate_session(session['token'])
            session.pop('token', None)
            
        return redirect(url_for('login'))
        
    def dashboard(self):
        """
        Render the dashboard page.
        """
        # Get statistics
        transaction_stats = self.transaction_monitor.get_transaction_stats()
        user_stats = self.user_manager.get_user_stats()
        
        return render_template('dashboard.html', 
                             transaction_stats=transaction_stats,
                             user_stats=user_stats)
        
    def transactions(self):
        """
        Render the transactions page.
        """
        # Get query parameters
        start_time = request.args.get('start_time')
        end_time = request.args.get('end_time')
        status = request.args.get('status')
        payment_method = request.args.get('payment_method')
        limit = int(request.args.get('limit', 50))
        offset = int(request.args.get('offset', 0))
        
        # Convert string timestamps to float if provided
        if start_time:
            start_time = float(start_time)
        if end_time:
            end_time = float(end_time)
            
        # Get transactions
        transactions = self.transaction_monitor.get_transactions(
            start_time=start_time,
            end_time=end_time,
            status=status,
            payment_method=payment_method,
            limit=limit,
            offset=offset
        )
        
        return render_template('transactions.html', 
                             transactions=transactions,
                             limit=limit,
                             offset=offset)
        
    def transaction_detail(self, transaction_id):
        """
        Render the transaction detail page.
        """
        transaction = self.transaction_monitor.get_transaction(transaction_id)
        
        if not transaction:
            return render_template('error.html', message='Transaction not found'), 404
            
        return render_template('transaction_detail.html', transaction=transaction)
        
    def export_transactions(self):
        """
        Export transactions to a file.
        """
        # Get query parameters
        start_time = request.args.get('start_time')
        end_time = request.args.get('end_time')
        format = request.args.get('format', 'json')
        
        # Convert string timestamps to float if provided
        if start_time:
            start_time = float(start_time)
        if end_time:
            end_time = float(end_time)
            
        # Export transactions
        exported_data = self.transaction_monitor.export_transactions(
            start_time=start_time,
            end_time=end_time,
            format=format
        )
        
        # Set content type based on format
        if format == 'json':
            content_type = 'application/json'
            filename = f'transactions_{int(time.time())}.json'
        elif format == 'csv':
            content_type = 'text/csv'
            filename = f'transactions_{int(time.time())}.csv'
        else:
            return render_template('error.html', message='Unsupported export format'), 400
            
        # Create response
        response = self.app.response_class(
            response=exported_data,
            status=200,
            mimetype=content_type
        )
        response.headers.set('Content-Disposition', f'attachment; filename={filename}')
        
        return response
        
    def users(self):
        """
        Render the users page.
        """
        # Get query parameters
        active_since = request.args.get('active_since')
        limit = int(request.args.get('limit', 50))
        offset = int(request.args.get('offset', 0))
        
        # Convert string timestamp to float if provided
        if active_since:
            active_since = float(active_since)
            
        # Get users
        users = self.user_manager.get_users(
            active_since=active_since,
            limit=limit,
            offset=offset
        )
        
        return render_template('users.html', 
                             users=users,
                             limit=limit,
                             offset=offset)
        
    def user_detail(self, user_id):
        """
        Render the user detail page.
        """
        user = self.user_manager.get_user(int(user_id))
        
        if not user:
            return render_template('error.html', message='User not found'), 404
            
        # Get user's transactions
        transactions = self.transaction_monitor.get_transactions(
            user_id=int(user_id),
            limit=10
        )
        
        return render_template('user_detail.html', 
                             user=user,
                             transactions=transactions)
        
    def block_user(self, user_id):
        """
        Block a user.
        """
        reason = request.form.get('reason', '')
        
        success = self.user_manager.block_user(int(user_id), reason)
        
        if not success:
            return render_template('error.html', message='Failed to block user'), 400
            
        return redirect(url_for('user_detail', user_id=user_id))
        
    def unblock_user(self, user_id):
        """
        Unblock a user.
        """
        success = self.user_manager.unblock_user(int(user_id))
        
        if not success:
            return render_template('error.html', message='Failed to unblock user'), 400
            
        return redirect(url_for('user_detail', user_id=user_id))
        
    def settings(self):
        """
        Render the settings page.
        """
        if request.method == 'POST':
            # Update settings
            new_settings = {}
            
            # Process form data
            for key, value in request.form.items():
                if key.startswith('settings.'):
                    setting_key = key[9:]  # Remove 'settings.' prefix
                    
                    # Convert value types
                    if value.lower() == 'true':
                        value = True
                    elif value.lower() == 'false':
                        value = False
                    elif value.isdigit():
                        value = int(value)
                    elif value.replace('.', '', 1).isdigit():
                        value = float(value)
                        
                    # Handle nested settings
                    if '.' in setting_key:
                        parts = setting_key.split('.')
                        current = new_settings
                        for part in parts[:-1]:
                            if part not in current:
                                current[part] = {}
                            current = current[part]
                        current[parts[-1]] = value
                    else:
                        new_settings[setting_key] = value
                        
            # Update settings
            success = self.settings_manager.update_settings(new_settings)
            
            if not success:
                return render_template('error.html', message='Failed to update settings'), 400
                
            return redirect(url_for('settings'))
            
        # Get current settings
        settings = self.settings_manager.get_settings()
        
        return render_template('settings.html', settings=settings)
        
    def export_settings(self):
        """
        Export settings to a file.
        """
        format = request.args.get('format', 'json')
        
        # Export settings
        exported_data = self.settings_manager.export_settings(format=format)
        
        # Set content type based on format
        if format == 'json':
            content_type = 'application/json'
            filename = f'settings_{int(time.time())}.json'
        else:
            return render_template('error.html', message='Unsupported export format'), 400
            
        # Create response
        response = self.app.response_class(
            response=exported_data,
            status=200,
            mimetype=content_type
        )
        response.headers.set('Content-Disposition', f'attachment; filename={filename}')
        
        return response
        
    def import_settings(self):
        """
        Import settings from a file.
        """
        if 'file' not in request.files:
            return render_template('error.html', message='No file provided'), 400
            
        file = request.files['file']
        
        if file.filename == '':
            return render_template('error.html', message='No file selected'), 400
            
        # Determine format from file extension
        if file.filename.endswith('.json'):
            format = 'json'
        else:
            return render_template('error.html', message='Unsupported file format'), 400
            
        # Read file content
        settings_data = file.read().decode('utf-8')
        
        # Import settings
        success = self.settings_manager.import_settings(settings_data, format=format)
        
        if not success:
            return render_template('error.html', message='Failed to import settings'), 400
            
        return redirect(url_for('settings'))
        
    def reset_settings(self):
        """
        Reset settings to defaults.
        """
        success = self.settings_manager.reset_settings()
        
        if not success:
            return render_template('error.html', message='Failed to reset settings'), 400
            
        return redirect(url_for('settings'))
        
    def api_stats(self):
        """
        API endpoint for statistics.
        """
        transaction_stats = self.transaction_monitor.get_transaction_stats()
        user_stats = self.user_manager.get_user_stats()
        
        return jsonify({
            'transactions': transaction_stats,
            'users': user_stats
        })
        
    def api_transactions(self):
        """
        API endpoint for transactions.
        """
        # Get query parameters
        start_time = request.args.get('start_time')
        end_time = request.args.get('end_time')
        status = request.args.get('status')
        payment_method = request.args.get('payment_method')
        limit = int(request.args.get('limit', 50))
        offset = int(request.args.get('offset', 0))
        
        # Convert string timestamps to float if provided
        if start_time:
            start_time = float(start_time)
        if end_time:
            end_time = float(end_time)
            
        # Get transactions
        transactions = self.transaction_monitor.get_transactions(
            start_time=start_time,
            end_time=end_time,
            status=status,
            payment_method=payment_method,
            limit=limit,
            offset=offset
        )
        
        return jsonify(transactions)
        
    def api_users(self):
        """
        API endpoint for users.
        """
        # Get query parameters
        active_since = request.args.get('active_since')
        limit = int(request.args.get('limit', 50))
        offset = int(request.args.get('offset', 0))
        
        # Convert string timestamp to float if provided
        if active_since:
            active_since = float(active_since)
            
        # Get users
        users = self.user_manager.get_users(
            active_since=active_since,
            limit=limit,
            offset=offset
        )
        
        return jsonify(users)
        
    def run(self, host='0.0.0.0', port=None, debug=False):
        """
        Run the admin panel web server.
        """
        port = port or config.ADMIN_PANEL_PORT
        
        self.logger.info(f"Starting admin panel on {host}:{port}")
        self.app.run(host=host, port=port, debug=debug)
        
if __name__ == "__main__":
    admin_panel = AdminPanel()
    admin_panel.run(debug=True)
