"""
Transaction monitoring module for the Telegram Mirror Bot admin panel.
"""
import time
import json
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from config import config
from src.logger import get_logger

logger = get_logger()

class TransactionMonitor:
    """
    Handles transaction monitoring for the admin panel.
    """
    def __init__(self):
        """
        Initialize the transaction monitoring module.
        """
        self.logger = logger
        
        # In a production environment, this would use a database
        # For now, we'll use an in-memory store
        self.transactions = []
        
        self.logger.info("TransactionMonitor initialized")
        
    async def record_transaction(self, transaction_data: Dict[str, Any]) -> str:
        """
        Record a new transaction.
        
        Args:
            transaction_data (dict): Transaction data to record
            
        Returns:
            str: Transaction ID
        """
        # Ensure transaction has an ID
        transaction_id = transaction_data.get('transaction_id', f"tx_{int(time.time())}")
        
        # Add timestamp if not present
        if 'timestamp' not in transaction_data:
            transaction_data['timestamp'] = time.time()
            
        # Add the transaction to our store
        self.transactions.append(transaction_data)
        
        self.logger.info(f"Recorded transaction {transaction_id}")
        
        return transaction_id
        
    async def get_transaction(self, transaction_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific transaction by ID.
        
        Args:
            transaction_id (str): Transaction ID to retrieve
            
        Returns:
            dict: Transaction data or None if not found
        """
        for transaction in self.transactions:
            if transaction.get('transaction_id') == transaction_id:
                return transaction
                
        return None
        
    async def get_transactions(self, 
                             start_time: Optional[float] = None,
                             end_time: Optional[float] = None,
                             user_id: Optional[int] = None,
                             status: Optional[str] = None,
                             payment_method: Optional[str] = None,
                             limit: int = 100,
                             offset: int = 0) -> List[Dict[str, Any]]:
        """
        Get transactions with optional filtering.
        
        Args:
            start_time (float, optional): Start timestamp
            end_time (float, optional): End timestamp
            user_id (int, optional): Filter by user ID
            status (str, optional): Filter by status
            payment_method (str, optional): Filter by payment method
            limit (int): Maximum number of transactions to return
            offset (int): Offset for pagination
            
        Returns:
            list: List of transaction data
        """
        # Apply filters
        filtered_transactions = self.transactions
        
        if start_time is not None:
            filtered_transactions = [tx for tx in filtered_transactions 
                                   if tx.get('timestamp', 0) >= start_time]
                                   
        if end_time is not None:
            filtered_transactions = [tx for tx in filtered_transactions 
                                   if tx.get('timestamp', 0) <= end_time]
                                   
        if user_id is not None:
            filtered_transactions = [tx for tx in filtered_transactions 
                                   if tx.get('user_id') == user_id]
                                   
        if status is not None:
            filtered_transactions = [tx for tx in filtered_transactions 
                                   if tx.get('status') == status]
                                   
        if payment_method is not None:
            filtered_transactions = [tx for tx in filtered_transactions 
                                   if tx.get('provider') == payment_method]
                                   
        # Sort by timestamp (newest first)
        filtered_transactions.sort(key=lambda tx: tx.get('timestamp', 0), reverse=True)
        
        # Apply pagination
        paginated_transactions = filtered_transactions[offset:offset + limit]
        
        return paginated_transactions
        
    async def get_transaction_stats(self, 
                                  start_time: Optional[float] = None,
                                  end_time: Optional[float] = None) -> Dict[str, Any]:
        """
        Get transaction statistics.
        
        Args:
            start_time (float, optional): Start timestamp
            end_time (float, optional): End timestamp
            
        Returns:
            dict: Transaction statistics
        """
        # Default to last 30 days if not specified
        if start_time is None:
            start_time = time.time() - (30 * 86400)
            
        if end_time is None:
            end_time = time.time()
            
        # Get transactions in the time range
        transactions = await self.get_transactions(start_time=start_time, end_time=end_time, limit=1000)
        
        # Calculate statistics
        total_count = len(transactions)
        total_amount = sum(tx.get('amount', 0) for tx in transactions)
        total_commission = sum(tx.get('commission_amount', 0) for tx in transactions)
        
        # Count by status
        status_counts = {}
        for tx in transactions:
            status = tx.get('status', 'unknown')
            status_counts[status] = status_counts.get(status, 0) + 1
            
        # Count by payment method
        method_counts = {}
        for tx in transactions:
            method = tx.get('provider', 'unknown')
            method_counts[method] = method_counts.get(method, 0) + 1
            
        # Daily transaction counts
        daily_counts = {}
        for tx in transactions:
            timestamp = tx.get('timestamp', 0)
            date_str = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d')
            daily_counts[date_str] = daily_counts.get(date_str, 0) + 1
            
        return {
            'total_count': total_count,
            'total_amount': total_amount,
            'total_commission': total_commission,
            'status_counts': status_counts,
            'method_counts': method_counts,
            'daily_counts': daily_counts
        }
        
    async def mark_transaction_forwarded(self, transaction_id: str) -> bool:
        """
        Mark a transaction as forwarded to the server owner.
        
        Args:
            transaction_id (str): Transaction ID to mark
            
        Returns:
            bool: True if successful
        """
        transaction = await self.get_transaction(transaction_id)
        
        if transaction:
            transaction['forwarded'] = True
            transaction['forwarded_at'] = time.time()
            self.logger.info(f"Marked transaction {transaction_id} as forwarded")
            return True
            
        return False
        
    async def export_transactions(self, 
                                start_time: Optional[float] = None,
                                end_time: Optional[float] = None,
                                format: str = 'json') -> str:
        """
        Export transactions to a specific format.
        
        Args:
            start_time (float, optional): Start timestamp
            end_time (float, optional): End timestamp
            format (str): Export format ('json' or 'csv')
            
        Returns:
            str: Exported data
        """
        transactions = await self.get_transactions(start_time=start_time, end_time=end_time, limit=1000)
        
        if format == 'json':
            return json.dumps(transactions, indent=2)
        elif format == 'csv':
            # Simple CSV export
            headers = ['transaction_id', 'timestamp', 'user_id', 'amount', 'currency', 
                      'commission_amount', 'status', 'provider', 'forwarded']
                      
            csv_lines = [','.join(headers)]
            
            for tx in transactions:
                row = []
                for header in headers:
                    value = tx.get(header, '')
                    # Format timestamp
                    if header == 'timestamp' and value:
                        value = datetime.fromtimestamp(value).strftime('%Y-%m-%d %H:%M:%S')
                    row.append(str(value))
                csv_lines.append(','.join(row))
                
            return '\n'.join(csv_lines)
        else:
            raise ValueError(f"Unsupported export format: {format}")
