"""
Coinbase Commerce payment gateway integration for the Telegram Mirror Bot.
"""
import json
import hmac
import hashlib
from typing import Dict, Any, Optional
from coinbase_commerce.client import Client
from config import config
from src.logger import get_logger

logger = get_logger()

class CoinbasePaymentGateway:
    """
    Handles cryptocurrency payment processing through Coinbase Commerce.
    """
    def __init__(self):
        """
        Initialize the Coinbase Commerce payment gateway.
        """
        self.logger = logger
        self.api_key = config.COINBASE_API_KEY
        self.webhook_secret = config.COINBASE_WEBHOOK_SECRET
        
        if not self.api_key:
            self.logger.error("Coinbase API key not configured. Please set COINBASE_API_KEY in .env file.")
            self.enabled = False
        else:
            self.client = Client(api_key=self.api_key)
            self.enabled = True
            self.logger.info("Coinbase Commerce payment gateway initialized")
            
    async def create_payment_link(self, payment_id: str, amount: float, currency: str, 
                                 description: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Create a Coinbase Commerce payment link.
        
        Args:
            payment_id (str): Unique payment ID
            amount (float): Payment amount
            currency (str): Currency code
            description (str): Payment description
            metadata (dict, optional): Additional metadata for the payment
            
        Returns:
            str: Coinbase Commerce payment URL
        """
        if not self.enabled:
            self.logger.error("Attempted to create Coinbase payment link but Coinbase is not enabled")
            return ""
            
        try:
            # Prepare metadata
            payment_metadata = {
                "payment_id": payment_id
            }
            
            if metadata:
                payment_metadata.update(metadata)
                
            # Create a charge
            charge_data = {
                "name": description,
                "description": f"Payment ID: {payment_id}",
                "pricing_type": "fixed_price",
                "local_price": {
                    "amount": str(amount),
                    "currency": currency
                },
                "metadata": payment_metadata
            }
            
            charge = self.client.charge.create(**charge_data)
            
            self.logger.info(f"Created Coinbase Commerce payment link for payment {payment_id}")
            return charge["hosted_url"]
            
        except Exception as e:
            self.logger.error(f"Error creating Coinbase Commerce payment link: {str(e)}")
            return ""
            
    async def verify_webhook_signature(self, payload: bytes, signature: str) -> bool:
        """
        Verify the signature of a Coinbase Commerce webhook.
        
        Args:
            payload (bytes): Raw webhook payload
            signature (str): Signature from Coinbase
            
        Returns:
            bool: True if signature is valid
        """
        if not self.enabled or not self.webhook_secret:
            return False
            
        try:
            # Create HMAC
            h = hmac.new(self.webhook_secret.encode('utf-8'), payload, hashlib.sha256)
            expected_signature = h.hexdigest()
            
            # Compare signatures
            return hmac.compare_digest(expected_signature, signature)
            
        except Exception as e:
            self.logger.error(f"Webhook signature verification failed: {str(e)}")
            return False
            
    async def process_webhook(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a Coinbase Commerce webhook payload.
        
        Args:
            payload (dict): Webhook payload
            
        Returns:
            dict: Processed payment information
        """
        if not self.enabled:
            return {"success": False, "error": "Coinbase Commerce is not enabled"}
            
        try:
            event_type = payload.get('event', {}).get('type')
            
            if event_type == 'charge:confirmed':
                charge = payload.get('event', {}).get('data', {})
                payment_id = charge.get('metadata', {}).get('payment_id')
                
                if payment_id:
                    # Get payment details
                    pricing = charge.get('pricing', {})
                    local_price = pricing.get('local', {})
                    amount = float(local_price.get('amount', '0'))
                    currency = local_price.get('currency', 'USD')
                    
                    return {
                        "success": True,
                        "payment_id": payment_id,
                        "amount": amount,
                        "currency": currency,
                        "status": "completed",
                        "provider": "coinbase",
                        "transaction_id": charge.get('id')
                    }
                    
            return {"success": False, "error": f"Unhandled event type: {event_type}"}
                
        except Exception as e:
            self.logger.error(f"Error processing Coinbase Commerce webhook: {str(e)}")
            return {"success": False, "error": str(e)}
