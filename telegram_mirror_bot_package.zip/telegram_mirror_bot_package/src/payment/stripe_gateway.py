"""
Stripe payment gateway integration for the Telegram Mirror Bot.
"""
import stripe
from typing import Dict, Any, Optional
from config import config
from src.logger import get_logger

logger = get_logger()

class StripePaymentGateway:
    """
    Handles payment processing through Stripe.
    """
    def __init__(self):
        """
        Initialize the Stripe payment gateway.
        """
        self.logger = logger
        self.api_key = config.STRIPE_API_KEY
        
        if not self.api_key:
            self.logger.error("Stripe API key not configured. Please set STRIPE_API_KEY in .env file.")
            self.enabled = False
        else:
            stripe.api_key = self.api_key
            self.enabled = True
            self.logger.info("Stripe payment gateway initialized")
            
    async def create_payment_link(self, payment_id: str, amount: float, currency: str, 
                                 description: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Create a Stripe payment link.
        
        Args:
            payment_id (str): Unique payment ID
            amount (float): Payment amount
            currency (str): Currency code
            description (str): Payment description
            metadata (dict, optional): Additional metadata for the payment
            
        Returns:
            str: Stripe payment URL
        """
        if not self.enabled:
            self.logger.error("Attempted to create Stripe payment link but Stripe is not enabled")
            return ""
            
        try:
            # Convert amount to cents for Stripe
            amount_cents = int(amount * 100)
            
            # Prepare metadata
            payment_metadata = {
                "payment_id": payment_id
            }
            
            if metadata:
                payment_metadata.update(metadata)
                
            # Create a payment link
            payment_link = stripe.PaymentLink.create(
                line_items=[
                    {
                        "price_data": {
                            "currency": currency.lower(),
                            "product_data": {
                                "name": description,
                                "description": f"Payment ID: {payment_id}",
                            },
                            "unit_amount": amount_cents,
                        },
                        "quantity": 1,
                    }
                ],
                metadata=payment_metadata
            )
            
            self.logger.info(f"Created Stripe payment link for payment {payment_id}")
            return payment_link.url
            
        except Exception as e:
            self.logger.error(f"Error creating Stripe payment link: {str(e)}")
            return ""
            
    async def verify_webhook_signature(self, payload: bytes, signature: str, webhook_secret: str) -> bool:
        """
        Verify the signature of a Stripe webhook.
        
        Args:
            payload (bytes): Raw webhook payload
            signature (str): Signature from Stripe
            webhook_secret (str): Webhook secret for verification
            
        Returns:
            bool: True if signature is valid
        """
        if not self.enabled:
            return False
            
        try:
            stripe.Webhook.construct_event(
                payload, signature, webhook_secret
            )
            return True
        except Exception as e:
            self.logger.error(f"Webhook signature verification failed: {str(e)}")
            return False
            
    async def process_webhook(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a Stripe webhook payload.
        
        Args:
            payload (dict): Webhook payload
            
        Returns:
            dict: Processed payment information
        """
        if not self.enabled:
            return {"success": False, "error": "Stripe is not enabled"}
            
        try:
            event_type = payload.get('type')
            
            if event_type == 'checkout.session.completed':
                session = payload.get('data', {}).get('object', {})
                payment_id = session.get('metadata', {}).get('payment_id')
                
                if payment_id:
                    amount = session.get('amount_total', 0) / 100  # Convert from cents
                    currency = session.get('currency', 'usd').upper()
                    
                    return {
                        "success": True,
                        "payment_id": payment_id,
                        "amount": amount,
                        "currency": currency,
                        "status": "completed",
                        "provider": "stripe",
                        "transaction_id": session.get('id')
                    }
                    
            return {"success": False, "error": f"Unhandled event type: {event_type}"}
                
        except Exception as e:
            self.logger.error(f"Error processing Stripe webhook: {str(e)}")
            return {"success": False, "error": str(e)}
