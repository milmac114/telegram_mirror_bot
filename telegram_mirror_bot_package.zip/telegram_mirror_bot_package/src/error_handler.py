"""
Error handling module for the Telegram Mirror Bot.
"""
import sys
import traceback
import asyncio
import functools
import inspect
from typing import Callable, Any, Dict, Optional, Type, List, Union
from telegram import Update
from telegram.ext import CallbackContext
from config import config
from src.logger import get_logger, log_exception

logger = get_logger('error_handler')

class ErrorHandler:
    """
    Handles error detection, reporting, and recovery for the Telegram Mirror Bot.
    """
    def __init__(self):
        """
        Initialize the error handler.
        """
        self.logger = logger
        self.notification_handlers = []
        self.error_counts = {}
        self.error_thresholds = {
            'critical': 1,  # Notify immediately for critical errors
            'error': 5,     # Notify after 5 errors of the same type
            'warning': 20   # Notify after 20 warnings of the same type
        }
        
        self.logger.info("ErrorHandler initialized")
        
    def register_notification_handler(self, handler: Callable[[str, Dict[str, Any]], None]) -> None:
        """
        Register a notification handler for critical errors.
        
        Args:
            handler: Function that takes error message and context
        """
        self.notification_handlers.append(handler)
        self.logger.info(f"Registered notification handler: {handler.__name__}")
        
    async def handle_telegram_error(self, update: Optional[Update], context: CallbackContext) -> None:
        """
        Handle errors raised during Telegram updates.
        
        Args:
            update: Telegram update that caused the error
            context: Callback context with error information
        """
        # Get the exception info
        error = context.error
        
        # Create context information
        error_context = {
            'update_id': update.update_id if update else None,
            'chat_id': update.effective_chat.id if update and update.effective_chat else None,
            'user_id': update.effective_user.id if update and update.effective_user else None,
            'message_id': update.effective_message.message_id if update and update.effective_message else None
        }
        
        # Log the exception
        log_exception(sys.exc_info(), error_context)
        
        # Notify about critical errors
        if isinstance(error, (KeyboardInterrupt, SystemExit)):
            # Don't handle these
            return
            
        error_type = error.__class__.__name__
        
        # Increment error count
        self.error_counts[error_type] = self.error_counts.get(error_type, 0) + 1
        
        # Determine severity
        severity = self._determine_severity(error)
        
        # Check if we should notify
        if self._should_notify(error_type, severity):
            await self._notify_error(error, severity, error_context)
            
        # Send message to user if appropriate
        if update and update.effective_chat:
            try:
                await update.effective_message.reply_text(
                    "Sorry, an error occurred while processing your request. "
                    "Our team has been notified and will fix it as soon as possible."
                )
            except Exception as e:
                self.logger.error(f"Failed to send error message to user: {str(e)}")
                
    def _determine_severity(self, error: Exception) -> str:
        """
        Determine the severity of an error.
        
        Args:
            error: The exception to evaluate
            
        Returns:
            str: Severity level ('critical', 'error', or 'warning')
        """
        # Critical errors
        if isinstance(error, (MemoryError, OSError, IOError, ConnectionError, TimeoutError)):
            return 'critical'
            
        # Regular errors
        if isinstance(error, Exception) and not isinstance(error, Warning):
            return 'error'
            
        # Warnings
        return 'warning'
        
    def _should_notify(self, error_type: str, severity: str) -> bool:
        """
        Determine if we should send a notification for this error.
        
        Args:
            error_type: Type of the error
            severity: Severity level
            
        Returns:
            bool: True if notification should be sent
        """
        count = self.error_counts.get(error_type, 0)
        threshold = self.error_thresholds.get(severity, 10)
        
        # Notify if count reaches threshold or is a multiple of threshold*10
        return count == threshold or (count > threshold and count % (threshold * 10) == 0)
        
    async def _notify_error(self, error: Exception, severity: str, context: Dict[str, Any]) -> None:
        """
        Send notifications about the error.
        
        Args:
            error: The exception that occurred
            severity: Severity level
            context: Additional context information
        """
        error_type = error.__class__.__name__
        error_message = str(error)
        count = self.error_counts.get(error_type, 0)
        
        notification_message = (
            f"{severity.upper()} ALERT: {error_type}\n"
            f"Message: {error_message}\n"
            f"Count: {count}\n"
            f"Context: {context}"
        )
        
        # Call all registered notification handlers
        for handler in self.notification_handlers:
            try:
                if inspect.iscoroutinefunction(handler):
                    await handler(notification_message, {
                        'error': error,
                        'severity': severity,
                        'context': context,
                        'count': count
                    })
                else:
                    handler(notification_message, {
                        'error': error,
                        'severity': severity,
                        'context': context,
                        'count': count
                    })
            except Exception as e:
                self.logger.error(f"Error in notification handler {handler.__name__}: {str(e)}")
                
    def handle_exception(self, func: Callable) -> Callable:
        """
        Decorator to handle exceptions in functions.
        
        Args:
            func: Function to wrap with exception handling
            
        Returns:
            Callable: Wrapped function
        """
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_exception(sys.exc_info(), {'function': func.__name__, 'args': args, 'kwargs': kwargs})
                raise
                
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                log_exception(sys.exc_info(), {'function': func.__name__, 'args': args, 'kwargs': kwargs})
                raise
                
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return wrapper
        
    def retry(self, max_retries: int = 3, retry_delay: float = 1.0, 
             exceptions: Union[Type[Exception], List[Type[Exception]]] = Exception) -> Callable:
        """
        Decorator to retry a function on exception.
        
        Args:
            max_retries: Maximum number of retry attempts
            retry_delay: Delay between retries in seconds
            exceptions: Exception type(s) to catch and retry
            
        Returns:
            Callable: Decorator function
        """
        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                last_exception = None
                for attempt in range(max_retries + 1):
                    try:
                        return func(*args, **kwargs)
                    except exceptions as e:
                        last_exception = e
                        if attempt < max_retries:
                            self.logger.warning(
                                f"Retry {attempt+1}/{max_retries} for {func.__name__} due to {e.__class__.__name__}: {str(e)}"
                            )
                            time.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
                        else:
                            log_exception(sys.exc_info(), {
                                'function': func.__name__, 
                                'args': args, 
                                'kwargs': kwargs,
                                'attempts': attempt + 1
                            })
                            
                # If we get here, all retries failed
                raise last_exception
                
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                last_exception = None
                for attempt in range(max_retries + 1):
                    try:
                        return await func(*args, **kwargs)
                    except exceptions as e:
                        last_exception = e
                        if attempt < max_retries:
                            self.logger.warning(
                                f"Retry {attempt+1}/{max_retries} for {func.__name__} due to {e.__class__.__name__}: {str(e)}"
                            )
                            await asyncio.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
                        else:
                            log_exception(sys.exc_info(), {
                                'function': func.__name__, 
                                'args': args, 
                                'kwargs': kwargs,
                                'attempts': attempt + 1
                            })
                            
                # If we get here, all retries failed
                raise last_exception
                
            if asyncio.iscoroutinefunction(func):
                return async_wrapper
            return wrapper
            
        return decorator

# Create a global instance
error_handler = ErrorHandler()

def handle_exceptions(func):
    """
    Decorator to handle exceptions in functions.
    """
    return error_handler.handle_exception(func)

def retry(max_retries=3, retry_delay=1.0, exceptions=Exception):
    """
    Decorator to retry a function on exception.
    """
    return error_handler.retry(max_retries, retry_delay, exceptions)
