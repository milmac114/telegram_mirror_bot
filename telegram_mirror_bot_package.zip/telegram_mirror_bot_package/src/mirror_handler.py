"""
Request and response handling module for the Telegram Mirror Bot.
"""
import json
import asyncio
from typing import Dict, Any, Optional, Tuple
from config import config
from src.logger import get_logger
from src.server_proxy import ServerProxy
from src.session_manager import SessionManager
from src.payment_handler import PaymentHandler

logger = get_logger()

class MirrorHandler:
    """
    Handles mirroring of requests and responses between Telegram users and the external server.
    """
    def __init__(self):
        """
        Initialize the mirror handler with necessary components.
        """
        self.logger = logger
        self.server_proxy = ServerProxy()
        self.session_manager = SessionManager()
        self.payment_handler = PaymentHandler()
        self.logger.info("MirrorHandler initialized")
        
    async def process_user_message(self, user_id: int, message_text: str) -> Dict[str, Any]:
        """
        Process a user message, forward it to the external server, and handle the response.
        
        Args:
            user_id (int): Telegram user ID
            message_text (str): User message text
            
        Returns:
            dict: Processed response for the user
        """
        self.logger.info(f"Processing message from user {user_id}")
        
        # Get or create user session
        session = await self.session_manager.get_session(user_id)
        
        # Check if user has a pending payment
        payment_status = await self.session_manager.get_payment_status(user_id)
        if payment_status.get("status") == "pending":
            # Check if the message is a payment confirmation
            if "payment" in message_text.lower() or "paid" in message_text.lower():
                return {
                    "message": "I'm checking your payment status. This may take a moment...",
                    "payment_check": True
                }
            
        # Prepare message context from session
        context = session.get("context", {})
        
        # Forward the request to the server
        server_response = await self.server_proxy.forward_request(user_id, message_text)
        
        # Process the server response
        processed_response = await self._process_server_response(user_id, server_response)
        
        # Update session context with any new information from the response
        if "context" in processed_response:
            await self.session_manager.update_session_context(user_id, processed_response["context"])
            # Remove context from the response to avoid sending it to the user
            del processed_response["context"]
            
        return processed_response
        
    async def _process_server_response(self, user_id: int, server_response: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process the response from the external server.
        
        Args:
            user_id (int): Telegram user ID
            server_response (dict): Response from the external server
            
        Returns:
            dict: Processed response for the user
        """
        # Check for errors
        if server_response.get("error"):
            self.logger.error(f"Server error for user {user_id}: {server_response.get('message')}")
            return {
                "message": server_response.get("message", "An error occurred while processing your request.")
            }
            
        # Check if payment is required
        if server_response.get("payment_required"):
            payment_info = server_response.get("payment_info", {})
            
            # Create payment request
            payment_message = await self.payment_handler.create_payment_request(
                user_id,
                payment_info.get("amount"),
                payment_info.get("currency", "USD"),
                payment_info.get("description", "Service payment")
            )
            
            # Update session with payment status
            await self.session_manager.set_payment_status(
                user_id,
                payment_info.get("payment_id"),
                "pending"
            )
            
            return {
                "message": payment_message,
                "payment_required": True,
                "payment_info": payment_info
            }
            
        # Extract context if present
        context = {}
        if "context" in server_response:
            context = server_response["context"]
            
        # Process any attachments or special content
        attachments = []
        if "attachments" in server_response:
            attachments = server_response["attachments"]
            
        # Return the processed response
        return {
            "message": server_response.get("message", ""),
            "attachments": attachments,
            "context": context
        }
        
    async def handle_payment_webhook(self, provider: str, payload: Dict[str, Any]) -> bool:
        """
        Handle payment webhook from payment providers.
        
        Args:
            provider (str): Payment provider name
            payload (dict): Webhook payload
            
        Returns:
            bool: True if payment was successfully processed
        """
        # Process the payment webhook
        payment_processed = await self.payment_handler.process_payment_webhook(provider, payload)
        
        if payment_processed:
            # Extract payment ID from the webhook payload
            payment_id = None
            if provider == "stripe":
                payment_id = payload.get("data", {}).get("object", {}).get("metadata", {}).get("payment_id")
            elif provider == "coinbase":
                payment_id = payload.get("event", {}).get("data", {}).get("metadata", {}).get("payment_id")
                
            if payment_id:
                # Find the user associated with this payment
                for session_id, session_data in self.session_manager.sessions.items():
                    if session_data.get("active_payment_id") == payment_id:
                        user_id = session_data.get("user_id")
                        
                        # Update session payment status
                        await self.session_manager.set_payment_status(user_id, payment_id, "completed")
                        
                        # Forward payment to server owner
                        await self.payment_handler.forward_payment_to_server_owner(payment_id)
                        
                        # Notify the server about the completed payment
                        await self.server_proxy.forward_request(
                            user_id,
                            f"__SYSTEM_MESSAGE__: Payment {payment_id} completed"
                        )
                        
                        self.logger.info(f"Payment {payment_id} processed for user {user_id}")
                        return True
                        
        return False
        
    async def handle_file_upload(self, user_id: int, file_data: bytes, file_name: str, file_type: str) -> Dict[str, Any]:
        """
        Handle file uploads from users and forward them to the external server.
        
        Args:
            user_id (int): Telegram user ID
            file_data (bytes): File binary data
            file_name (str): Original file name
            file_type (str): MIME type of the file
            
        Returns:
            dict: Server response
        """
        self.logger.info(f"Handling file upload from user {user_id}: {file_name} ({file_type})")
        
        # In a real implementation, this would forward the file to the external server
        # For now, we'll just return a placeholder response
        
        return {
            "message": f"Your file '{file_name}' has been received and processed.",
            "context": {
                "last_file_name": file_name,
                "last_file_type": file_type
            }
        }
