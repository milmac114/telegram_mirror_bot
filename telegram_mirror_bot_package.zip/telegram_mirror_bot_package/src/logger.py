"""
Enhanced logging module for the Telegram Mirror Bot.
"""
import os
import logging
import traceback
import json
import time
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
import sys
from datetime import datetime
from config import config

# Create logs directory if it doesn't exist
logs_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
os.makedirs(logs_dir, exist_ok=True)

# Configure main logger
main_logger = logging.getLogger('telegram_mirror_bot')
main_logger.setLevel(getattr(logging, config.LOG_LEVEL))
main_logger.propagate = False  # Prevent double logging

# Create console handler with formatting
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setLevel(getattr(logging, config.LOG_LEVEL))
console_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(console_format)

# Create file handler for main log with rotation by size
main_log_file = os.path.join(logs_dir, 'bot.log')
file_handler = RotatingFileHandler(
    main_log_file,
    maxBytes=10485760,  # 10MB
    backupCount=10
)
file_handler.setLevel(getattr(logging, config.LOG_LEVEL))
file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(file_format)

# Create daily rotating file handler for error logs
error_log_file = os.path.join(logs_dir, 'error.log')
error_handler = TimedRotatingFileHandler(
    error_log_file,
    when='midnight',
    interval=1,
    backupCount=30
)
error_handler.setLevel(logging.ERROR)
error_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
error_handler.setFormatter(error_format)

# Create JSON handler for structured logging
json_log_file = os.path.join(logs_dir, 'structured.log')
json_handler = RotatingFileHandler(
    json_log_file,
    maxBytes=10485760,  # 10MB
    backupCount=10
)
json_handler.setLevel(getattr(logging, config.LOG_LEVEL))

class JsonFormatter(logging.Formatter):
    """
    Formatter for JSON structured logging.
    """
    def format(self, record):
        log_data = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }
        
        # Add exception info if available
        if record.exc_info:
            log_data['exception'] = {
                'type': record.exc_info[0].__name__,
                'message': str(record.exc_info[1]),
                'traceback': traceback.format_exception(*record.exc_info)
            }
            
        # Add extra fields if available
        if hasattr(record, 'extra'):
            log_data.update(record.extra)
            
        return json.dumps(log_data)

json_handler.setFormatter(JsonFormatter())

# Add handlers to logger
main_logger.addHandler(console_handler)
main_logger.addHandler(file_handler)
main_logger.addHandler(error_handler)
main_logger.addHandler(json_handler)

# Create specialized loggers
transaction_logger = logging.getLogger('telegram_mirror_bot.transactions')
transaction_logger.setLevel(getattr(logging, config.LOG_LEVEL))
transaction_logger.propagate = False

# Create transaction log file handler
transaction_log_file = os.path.join(logs_dir, 'transactions.log')
transaction_handler = RotatingFileHandler(
    transaction_log_file,
    maxBytes=10485760,  # 10MB
    backupCount=10
)
transaction_handler.setLevel(getattr(logging, config.LOG_LEVEL))
transaction_handler.setFormatter(JsonFormatter())
transaction_logger.addHandler(transaction_handler)

# Create security logger
security_logger = logging.getLogger('telegram_mirror_bot.security')
security_logger.setLevel(getattr(logging, config.LOG_LEVEL))
security_logger.propagate = False

# Create security log file handler
security_log_file = os.path.join(logs_dir, 'security.log')
security_handler = RotatingFileHandler(
    security_log_file,
    maxBytes=10485760,  # 10MB
    backupCount=10
)
security_handler.setLevel(getattr(logging, config.LOG_LEVEL))
security_handler.setFormatter(JsonFormatter())
security_logger.addHandler(security_handler)

def get_logger(name=None):
    """
    Get a logger instance.
    
    Args:
        name (str, optional): Logger name suffix
        
    Returns:
        logging.Logger: Logger instance
    """
    if name:
        return logging.getLogger(f'telegram_mirror_bot.{name}')
    return main_logger

def get_transaction_logger():
    """
    Get the transaction logger instance.
    
    Returns:
        logging.Logger: Transaction logger instance
    """
    return transaction_logger

def get_security_logger():
    """
    Get the security logger instance.
    
    Returns:
        logging.Logger: Security logger instance
    """
    return security_logger

def log_transaction(transaction_data):
    """
    Log a transaction with structured data.
    
    Args:
        transaction_data (dict): Transaction data to log
    """
    transaction_logger.info(
        f"Transaction {transaction_data.get('transaction_id')}: "
        f"{transaction_data.get('amount')} {transaction_data.get('currency')} "
        f"via {transaction_data.get('provider')}",
        extra={'transaction': transaction_data}
    )

def log_security_event(event_type, user_id=None, details=None):
    """
    Log a security event.
    
    Args:
        event_type (str): Type of security event
        user_id (int, optional): User ID related to the event
        details (dict, optional): Additional event details
    """
    event_data = {
        'event_type': event_type,
        'timestamp': time.time()
    }
    
    if user_id:
        event_data['user_id'] = user_id
        
    if details:
        event_data['details'] = details
        
    security_logger.info(
        f"Security event: {event_type}" + 
        (f" for user {user_id}" if user_id else ""),
        extra={'security_event': event_data}
    )

def log_exception(exc_info, context=None):
    """
    Log an exception with context.
    
    Args:
        exc_info: Exception info tuple from sys.exc_info()
        context (dict, optional): Additional context information
    """
    exc_type, exc_value, exc_traceback = exc_info
    
    log_data = {
        'exception_type': exc_type.__name__,
        'exception_message': str(exc_value),
        'traceback': traceback.format_exception(exc_type, exc_value, exc_traceback)
    }
    
    if context:
        log_data['context'] = context
        
    main_logger.error(
        f"Exception: {exc_type.__name__}: {str(exc_value)}",
        extra={'exception_data': log_data},
        exc_info=exc_info
    )
