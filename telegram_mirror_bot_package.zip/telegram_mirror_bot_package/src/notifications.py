"""
Notification system for the Telegram Mirror Bot.
"""
import os
import smtplib
import requests
import json
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, Any, List, Optional
from config import config
from src.logger import get_logger

logger = get_logger('notifications')

class NotificationSystem:
    """
    Handles sending notifications for critical events and errors.
    """
    def __init__(self):
        """
        Initialize the notification system.
        """
        self.logger = logger
        self.email_enabled = bool(config.SMTP_SERVER and config.SMTP_PORT and 
                                config.SMTP_USERNAME and config.SMTP_PASSWORD)
        self.webhook_enabled = bool(config.WEBHOOK_URL)
        self.telegram_enabled = bool(config.ADMIN_NOTIFICATION_CHAT_ID and config.BOT_TOKEN)
        
        self.logger.info("NotificationSystem initialized")
        
    async def send_notification(self, message: str, context: Dict[str, Any] = None) -> bool:
        """
        Send a notification through all configured channels.
        
        Args:
            message (str): Notification message
            context (dict, optional): Additional context information
            
        Returns:
            bool: True if at least one notification was sent successfully
        """
        success = False
        
        # Add severity prefix if available
        if context and 'severity' in context:
            severity = context['severity'].upper()
            if not message.startswith(severity):
                message = f"{severity}: {message}"
                
        # Try all enabled notification methods
        if self.email_enabled:
            email_success = await self.send_email_notification(message, context)
            success = success or email_success
            
        if self.webhook_enabled:
            webhook_success = await self.send_webhook_notification(message, context)
            success = success or webhook_success
            
        if self.telegram_enabled:
            telegram_success = await self.send_telegram_notification(message, context)
            success = success or telegram_success
            
        return success
        
    async def send_email_notification(self, message: str, context: Dict[str, Any] = None) -> bool:
        """
        Send a notification via email.
        
        Args:
            message (str): Notification message
            context (dict, optional): Additional context information
            
        Returns:
            bool: True if successful
        """
        if not self.email_enabled:
            return False
            
        try:
            # Create message
            msg = MIMEMultipart()
            msg['From'] = config.SMTP_USERNAME
            msg['To'] = config.ADMIN_EMAIL
            
            # Set subject based on severity
            severity = "ALERT"
            if context and 'severity' in context:
                severity = context['severity'].upper()
                
            msg['Subject'] = f"Telegram Mirror Bot {severity}: {message[:50]}..."
            
            # Create message body
            body = message
            
            # Add context information if available
            if context:
                body += "\n\nContext:\n"
                for key, value in context.items():
                    if key != 'error':  # Skip the actual error object
                        body += f"{key}: {value}\n"
                        
            msg.attach(MIMEText(body, 'plain'))
            
            # Connect to SMTP server and send email
            server = smtplib.SMTP(config.SMTP_SERVER, config.SMTP_PORT)
            server.starttls()
            server.login(config.SMTP_USERNAME, config.SMTP_PASSWORD)
            server.send_message(msg)
            server.quit()
            
            self.logger.info(f"Sent email notification to {config.ADMIN_EMAIL}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to send email notification: {str(e)}")
            return False
            
    async def send_webhook_notification(self, message: str, context: Dict[str, Any] = None) -> bool:
        """
        Send a notification via webhook.
        
        Args:
            message (str): Notification message
            context (dict, optional): Additional context information
            
        Returns:
            bool: True if successful
        """
        if not self.webhook_enabled:
            return False
            
        try:
            # Prepare payload
            payload = {
                'message': message,
                'timestamp': time.time()
            }
            
            # Add context information if available
            if context:
                clean_context = {}
                for key, value in context.items():
                    if key != 'error':  # Skip the actual error object
                        clean_context[key] = value
                payload['context'] = clean_context
                
            # Send webhook request
            response = requests.post(
                config.WEBHOOK_URL,
                json=payload,
                headers={'Content-Type': 'application/json'},
                timeout=10
            )
            
            if response.status_code == 200:
                self.logger.info(f"Sent webhook notification to {config.WEBHOOK_URL}")
                return True
            else:
                self.logger.error(f"Webhook notification failed with status {response.status_code}: {response.text}")
                return False
                
        except Exception as e:
            self.logger.error(f"Failed to send webhook notification: {str(e)}")
            return False
            
    async def send_telegram_notification(self, message: str, context: Dict[str, Any] = None) -> bool:
        """
        Send a notification via Telegram.
        
        Args:
            message (str): Notification message
            context (dict, optional): Additional context information
            
        Returns:
            bool: True if successful
        """
        if not self.telegram_enabled:
            return False
            
        try:
            # Format message for Telegram
            telegram_message = message
            
            # Add context information if available
            if context:
                telegram_message += "\n\nContext:\n"
                for key, value in context.items():
                    if key != 'error':  # Skip the actual error object
                        telegram_message += f"{key}: {value}\n"
                        
            # Send Telegram message
            url = f"https://api.telegram.org/bot{config.BOT_TOKEN}/sendMessage"
            payload = {
                'chat_id': config.ADMIN_NOTIFICATION_CHAT_ID,
                'text': telegram_message,
                'parse_mode': 'Markdown'
            }
            
            response = requests.post(
                url,
                json=payload,
                headers={'Content-Type': 'application/json'},
                timeout=10
            )
            
            if response.status_code == 200:
                self.logger.info(f"Sent Telegram notification to chat {config.ADMIN_NOTIFICATION_CHAT_ID}")
                return True
            else:
                self.logger.error(f"Telegram notification failed with status {response.status_code}: {response.text}")
                return False
                
        except Exception as e:
            self.logger.error(f"Failed to send Telegram notification: {str(e)}")
            return False

# Create a global instance
notification_system = NotificationSystem()

async def send_notification(message, context=None):
    """
    Send a notification through all configured channels.
    """
    return await notification_system.send_notification(message, context)
