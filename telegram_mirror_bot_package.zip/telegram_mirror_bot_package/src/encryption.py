"""
Encryption module for the Telegram Mirror Bot.
"""
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from config import config
from src.logger import get_logger

logger = get_logger()

def _get_encryption_key():
    """
    Derive a Fernet key from the configured encryption key.
    
    Returns:
        bytes: Derived Fernet key
    """
    if not config.ENCRYPTION_KEY:
        logger.error("Encryption key not configured. Please set ENCRYPTION_KEY in .env file.")
        raise ValueError("Encryption key not configured")
    
    # Use PBKDF2 to derive a key from the configured encryption key
    salt = b'telegram_mirror_bot_salt'  # Fixed salt for consistency
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    
    key = base64.urlsafe_b64encode(kdf.derive(config.ENCRYPTION_KEY.encode()))
    return key

def encrypt_data(data):
    """
    Encrypt data using Fernet symmetric encryption.
    
    Args:
        data (str): Data to encrypt
        
    Returns:
        str: Base64-encoded encrypted data
    """
    try:
        key = _get_encryption_key()
        f = Fernet(key)
        encrypted_data = f.encrypt(data.encode())
        return base64.b64encode(encrypted_data).decode()
    except Exception as e:
        logger.error(f"Encryption error: {str(e)}")
        raise

def decrypt_data(encrypted_data):
    """
    Decrypt data that was encrypted with encrypt_data.
    
    Args:
        encrypted_data (str): Base64-encoded encrypted data
        
    Returns:
        str: Decrypted data
    """
    try:
        key = _get_encryption_key()
        f = Fernet(key)
        decrypted_data = f.decrypt(base64.b64decode(encrypted_data))
        return decrypted_data.decode()
    except Exception as e:
        logger.error(f"Decryption error: {str(e)}")
        raise
