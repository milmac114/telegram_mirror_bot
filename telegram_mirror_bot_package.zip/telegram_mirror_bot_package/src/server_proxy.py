"""
Server proxy module for the Telegram Mirror Bot.
"""
import aiohttp
import json
from config import config
from src.logger import get_logger
from src.encryption import encrypt_data, decrypt_data
from src.anonymity.privacy_protection import PrivacyProtection

logger = get_logger()

class ServerProxy:
    """
    Handles communication with the external server while maintaining anonymity.
    """
    def __init__(self):
        """
        Initialize the server proxy with configuration.
        """
        self.server_url = config.SERVER_URL
        self.api_key = config.SERVER_API_KEY
        self.timeout = config.SERVER_TIMEOUT
        self.logger = logger
        self.privacy_protection = PrivacyProtection()
        
        if not self.server_url:
            self.logger.error("Server URL not configured. Please set SERVER_URL in .env file.")
        
        self.logger.info(f"ServerProxy initialized with URL: {self.server_url}")
        
    async def forward_request(self, user_id, message):
        """
        Forward user request to the external server and return the response.
        
        Args:
            user_id (int): Telegram user ID
            message (str): User message to forward
            
        Returns:
            dict: Server response
        """
        self.logger.info(f"Forwarding request for user {user_id}")
        
        # Create a unique session ID for this user if not exists
        session_id = f"tg_{user_id}"
        
        # Prepare request data
        request_data = {
            "session_id": session_id,
            "message": message,
            "timestamp": None  # Will be added by the server
        }
        
        # Apply privacy protection to the request
        protected_request = await self.privacy_protection.process_outgoing_request(user_id, request_data)
        
        # Prepare headers with anonymized information
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "X-Client-ID": "anonymous-client"
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                # If the request is encrypted, send the encrypted data
                if protected_request.get("encrypted", False):
                    request_body = {"encrypted": True, "data": protected_request["data"]}
                else:
                    # Otherwise, encrypt with basic encryption
                    encrypted_data = encrypt_data(json.dumps(protected_request["data"]))
                    request_body = {"data": encrypted_data}
                
                async with session.post(
                    f"{self.server_url}/api/message",
                    headers=headers,
                    json=request_body,
                    timeout=self.timeout
                ) as response:
                    if response.status == 200:
                        response_data = await response.json()
                        
                        # Process the response through privacy protection
                        if "encrypted_response" in response_data:
                            # Handle legacy encryption format
                            decrypted_response = decrypt_data(response_data["encrypted_response"])
                            parsed_response = json.loads(decrypted_response)
                            return await self.privacy_protection.process_incoming_response(user_id, parsed_response)
                        else:
                            # Handle new encryption format
                            return await self.privacy_protection.process_incoming_response(user_id, response_data)
                    else:
                        error_text = await response.text()
                        self.logger.error(f"Server returned error {response.status}: {error_text}")
                        return {
                            "error": True,
                            "message": f"The service is currently unavailable. Please try again later."
                        }
        except aiohttp.ClientError as e:
            self.logger.error(f"Connection error: {str(e)}")
            return {
                "error": True,
                "message": "Unable to connect to the service. Please try again later."
            }
        except Exception as e:
            self.logger.error(f"Unexpected error in forward_request: {str(e)}")
            return {
                "error": True,
                "message": "An unexpected error occurred. Please try again later."
            }
