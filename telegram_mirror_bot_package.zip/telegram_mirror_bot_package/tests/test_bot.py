"""
Test cases for the Telegram Mirror Bot.
"""
import unittest
import asyncio
import os
import sys
from unittest.mock import MagicMock, patch, AsyncMock
from telegram import Update, User, Chat, Message

# Add the project root directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.bot import TelegramMirrorBot
from src.mirror_handler import MirrorHandler
from src.server_proxy import ServerProxy
from src.session_manager import SessionManager
from src.payment_handler import PaymentHandler
from src.anonymity.privacy_protection import PrivacyProtection

class TestTelegramMirrorBot(unittest.TestCase):
    """
    Test cases for the TelegramMirrorBot class.
    """
    
    def setUp(self):
        """
        Set up test environment before each test.
        """
        # Mock dependencies
        self.mirror_handler_mock = MagicMock(spec=MirrorHandler)
        self.mirror_handler_mock.process_user_message = AsyncMock()
        self.mirror_handler_mock.handle_file_upload = AsyncMock()
        self.mirror_handler_mock.session_manager = MagicMock(spec=SessionManager)
        self.mirror_handler_mock.session_manager.clear_session = AsyncMock()
        self.mirror_handler_mock.session_manager.get_payment_status = AsyncMock()
        
        # Create a bot instance with mocked dependencies
        with patch('src.bot.MirrorHandler', return_value=self.mirror_handler_mock):
            self.bot = TelegramMirrorBot()
            
        # Mock application
        self.bot.application = MagicMock()
        
        # Create mock update and context
        self.update = MagicMock(spec=Update)
        self.context = MagicMock()
        
        # Mock user, chat, and message
        self.user = MagicMock(spec=User)
        self.user.id = 12345
        self.user.first_name = "Test"
        
        self.chat = MagicMock(spec=Chat)
        self.chat.id = 12345
        
        self.message = MagicMock(spec=Message)
        self.message.text = "Test message"
        self.message.reply_text = AsyncMock()
        
        # Set up update with user, chat, and message
        self.update.effective_user = self.user
        self.update.effective_chat = self.chat
        self.update.message = self.message
        self.update.effective_message = self.message
        
    def asyncSetUp(self):
        """
        Async setup for tests.
        """
        pass
        
    def asyncTearDown(self):
        """
        Async teardown for tests.
        """
        pass
        
    def run_async(self, coro):
        """
        Run an async coroutine in the test.
        """
        return asyncio.get_event_loop().run_until_complete(coro)
        
    def test_init(self):
        """
        Test bot initialization.
        """
        self.assertIsNotNone(self.bot)
        self.assertEqual(self.bot.mirror_handler, self.mirror_handler_mock)
        
    def test_start_command(self):
        """
        Test the /start command.
        """
        # Run the start command
        self.run_async(self.bot.start_command(self.update, self.context))
        
        # Check that reply_text was called
        self.message.reply_text.assert_called_once()
        
        # Check that the welcome message contains the user's name
        call_args = self.message.reply_text.call_args[0][0]
        self.assertIn(self.user.first_name, call_args)
        
    def test_help_command(self):
        """
        Test the /help command.
        """
        # Run the help command
        self.run_async(self.bot.help_command(self.update, self.context))
        
        # Check that reply_text was called
        self.message.reply_text.assert_called_once()
        
        # Check that the help message contains command information
        call_args = self.message.reply_text.call_args[0][0]
        self.assertIn("/start", call_args)
        self.assertIn("/help", call_args)
        self.assertIn("/reset", call_args)
        
        # Check that Markdown parsing is enabled
        call_kwargs = self.message.reply_text.call_args[1]
        self.assertEqual(call_kwargs.get("parse_mode"), "Markdown")
        
    def test_reset_command(self):
        """
        Test the /reset command.
        """
        # Run the reset command
        self.run_async(self.bot.reset_command(self.update, self.context))
        
        # Check that session was cleared
        self.mirror_handler_mock.session_manager.clear_session.assert_called_once_with(self.user.id)
        
        # Check that reply_text was called
        self.message.reply_text.assert_called_once()
        
        # Check that the reset message is appropriate
        call_args = self.message.reply_text.call_args[0][0]
        self.assertIn("reset", call_args.lower())
        
    def test_handle_message_normal_response(self):
        """
        Test handling a normal message.
        """
        # Mock the chat action
        self.update.effective_chat.send_chat_action = AsyncMock()
        
        # Set up the mock response
        self.mirror_handler_mock.process_user_message.return_value = {
            "message": "Server response"
        }
        
        # Run the message handler
        self.run_async(self.bot.handle_message(self.update, self.context))
        
        # Check that typing indicator was shown
        self.update.effective_chat.send_chat_action.assert_called_once_with("typing")
        
        # Check that the message was processed
        self.mirror_handler_mock.process_user_message.assert_called_once_with(
            self.user.id, self.message.text
        )
        
        # Check that reply_text was called with the server response
        self.message.reply_text.assert_called_once_with("Server response")
        
    def test_handle_message_payment_required(self):
        """
        Test handling a message that requires payment.
        """
        # Mock the chat action
        self.update.effective_chat.send_chat_action = AsyncMock()
        
        # Set up the mock response
        self.mirror_handler_mock.process_user_message.return_value = {
            "payment_required": True,
            "message": "Payment required message"
        }
        
        # Run the message handler
        self.run_async(self.bot.handle_message(self.update, self.context))
        
        # Check that typing indicator was shown
        self.update.effective_chat.send_chat_action.assert_called_once_with("typing")
        
        # Check that the message was processed
        self.mirror_handler_mock.process_user_message.assert_called_once_with(
            self.user.id, self.message.text
        )
        
        # Check that reply_text was called with the payment message
        self.message.reply_text.assert_called_once_with(
            "Payment required message",
            parse_mode="Markdown"
        )
        
    def test_handle_message_with_error(self):
        """
        Test handling a message when an error occurs.
        """
        # Mock the chat action
        self.update.effective_chat.send_chat_action = AsyncMock()
        
        # Set up the mock to raise an exception
        self.mirror_handler_mock.process_user_message.side_effect = Exception("Test error")
        
        # Run the message handler
        self.run_async(self.bot.handle_message(self.update, self.context))
        
        # Check that typing indicator was shown
        self.update.effective_chat.send_chat_action.assert_called_once_with("typing")
        
        # Check that the message was attempted to be processed
        self.mirror_handler_mock.process_user_message.assert_called_once_with(
            self.user.id, self.message.text
        )
        
        # Check that reply_text was called with an error message
        self.message.reply_text.assert_called_once()
        call_args = self.message.reply_text.call_args[0][0]
        self.assertIn("error", call_args.lower())
        
    def test_error_handler(self):
        """
        Test the error handler.
        """
        # Create a context with an error
        context = MagicMock()
        context.error = Exception("Test error")
        
        # Run the error handler
        with patch('src.bot.error_handler') as error_handler_mock:
            error_handler_mock.handle_telegram_error = AsyncMock()
            self.run_async(self.bot.error_handler(self.update, context))
            
            # Check that the error handler was called
            error_handler_mock.handle_telegram_error.assert_called_once_with(self.update, context)

class TestMirrorHandler(unittest.TestCase):
    """
    Test cases for the MirrorHandler class.
    """
    
    def setUp(self):
        """
        Set up test environment before each test.
        """
        # Mock dependencies
        self.server_proxy_mock = MagicMock(spec=ServerProxy)
        self.server_proxy_mock.forward_request = AsyncMock()
        
        self.session_manager_mock = MagicMock(spec=SessionManager)
        self.session_manager_mock.get_session = AsyncMock()
        self.session_manager_mock.update_session = AsyncMock()
        
        self.payment_handler_mock = MagicMock(spec=PaymentHandler)
        self.payment_handler_mock.create_payment_request = AsyncMock()
        
        self.privacy_protection_mock = MagicMock(spec=PrivacyProtection)
        
        # Create a mirror handler instance with mocked dependencies
        with patch('src.mirror_handler.ServerProxy', return_value=self.server_proxy_mock), \
             patch('src.mirror_handler.SessionManager', return_value=self.session_manager_mock), \
             patch('src.mirror_handler.PaymentHandler', return_value=self.payment_handler_mock), \
             patch('src.mirror_handler.PrivacyProtection', return_value=self.privacy_protection_mock):
            self.mirror_handler = MirrorHandler()
            
    def asyncSetUp(self):
        """
        Async setup for tests.
        """
        pass
        
    def asyncTearDown(self):
        """
        Async teardown for tests.
        """
        pass
        
    def run_async(self, coro):
        """
        Run an async coroutine in the test.
        """
        return asyncio.get_event_loop().run_until_complete(coro)
        
    def test_init(self):
        """
        Test mirror handler initialization.
        """
        self.assertIsNotNone(self.mirror_handler)
        self.assertEqual(self.mirror_handler.server_proxy, self.server_proxy_mock)
        self.assertEqual(self.mirror_handler.session_manager, self.session_manager_mock)
        self.assertEqual(self.mirror_handler.payment_handler, self.payment_handler_mock)
        
    def test_process_user_message_normal(self):
        """
        Test processing a normal user message.
        """
        # Set up mock session
        self.session_manager_mock.get_session.return_value = {"user_id": 12345}
        
        # Set up mock server response
        self.server_proxy_mock.forward_request.return_value = {
            "message": "Server response"
        }
        
        # Process a message
        response = self.run_async(self.mirror_handler.process_user_message(12345, "Test message"))
        
        # Check that session was retrieved
        self.session_manager_mock.get_session.assert_called_once_with(12345)
        
        # Check that request was forwarded
        self.server_proxy_mock.forward_request.assert_called_once_with(12345, "Test message")
        
        # Check that session was updated
        self.session_manager_mock.update_session.assert_called_once()
        
        # Check response
        self.assertEqual(response, {"message": "Server response"})
        
    def test_process_user_message_payment_required(self):
        """
        Test processing a message that requires payment.
        """
        # Set up mock session
        self.session_manager_mock.get_session.return_value = {"user_id": 12345}
        
        # Set up mock server response
        self.server_proxy_mock.forward_request.return_value = {
            "payment_required": True,
            "amount": 10.0,
            "currency": "USD"
        }
        
        # Set up mock payment request
        self.payment_handler_mock.create_payment_request.return_value = "Payment instructions"
        
        # Process a message
        response = self.run_async(self.mirror_handler.process_user_message(12345, "Test message"))
        
        # Check that session was retrieved
        self.session_manager_mock.get_session.assert_called_once_with(12345)
        
        # Check that request was forwarded
        self.server_proxy_mock.forward_request.assert_called_once_with(12345, "Test message")
        
        # Check that payment request was created
        self.payment_handler_mock.create_payment_request.assert_called_once()
        call_args = self.payment_handler_mock.create_payment_request.call_args[0]
        self.assertEqual(call_args[0], 12345)  # user_id
        self.assertEqual(call_args[1], 10.0)   # amount
        self.assertEqual(call_args[2], "USD")  # currency
        
        # Check that session was updated
        self.session_manager_mock.update_session.assert_called_once()
        
        # Check response
        self.assertEqual(response["payment_required"], True)
        self.assertEqual(response["message"], "Payment instructions")
        
    def test_handle_file_upload(self):
        """
        Test handling a file upload.
        """
        # Set up mock session
        self.session_manager_mock.get_session.return_value = {"user_id": 12345}
        
        # Set up mock server response
        self.server_proxy_mock.forward_request.return_value = {
            "message": "File received"
        }
        
        # Process a file upload
        file_data = b"test file content"
        filename = "test.txt"
        mime_type = "text/plain"
        
        response = self.run_async(self.mirror_handler.handle_file_upload(
            12345, file_data, filename, mime_type
        ))
        
        # Check that session was retrieved
        self.session_manager_mock.get_session.assert_called_once_with(12345)
        
        # Check that request was forwarded with file info
        self.server_proxy_mock.forward_request.assert_called_once()
        call_args = self.server_proxy_mock.forward_request.call_args[0]
        self.assertEqual(call_args[0], 12345)  # user_id
        
        # The second argument should contain file information
        message_arg = call_args[1]
        self.assertIn("FILE_UPLOAD", message_arg)
        self.assertIn(filename, message_arg)
        self.assertIn(mime_type, message_arg)
        
        # Check that session was updated
        self.session_manager_mock.update_session.assert_called_once()
        
        # Check response
        self.assertEqual(response, {"message": "File received"})

if __name__ == '__main__':
    unittest.main()
