"""
Integration tests for the Telegram Mirror Bot.
"""
import unittest
import asyncio
import os
import sys
import json
import time
from unittest.mock import MagicMock, patch, AsyncMock
import requests

# Add the project root directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.bot import TelegramMirrorBot
from src.server_proxy import ServerProxy
from src.payment_handler import PaymentHandler
from src.admin.admin_panel import AdminPanel
from config import config

class TestIntegration(unittest.TestCase):
    """
    Integration tests for the Telegram Mirror Bot.
    """
    
    @classmethod
    def setUpClass(cls):
        """
        Set up test environment once before all tests.
        """
        # Create a test configuration
        cls.test_config = {
            "BOT_TOKEN": os.environ.get("TEST_BOT_TOKEN", "test_token"),
            "EXTERNAL_SERVER_URL": "http://localhost:8080/mock_server",
            "COMMISSION_PERCENTAGE": 10,
            "ADMIN_USERNAME": "admin",
            "ADMIN_PASSWORD": "password",
            "WEBHOOK_URL": "http://localhost:8080/webhook"
        }
        
        # Create a mock server
        cls.mock_server_process = None
        
    @classmethod
    def tearDownClass(cls):
        """
        Clean up after all tests.
        """
        # Stop the mock server if it's running
        if cls.mock_server_process:
            cls.mock_server_process.terminate()
            cls.mock_server_process.wait()
            
    def setUp(self):
        """
        Set up test environment before each test.
        """
        # Create a patched configuration
        self.config_patcher = patch('config.config', self.test_config)
        self.config_mock = self.config_patcher.start()
        
        # Start a mock server for integration tests
        self.start_mock_server()
        
        # Wait for the server to start
        time.sleep(1)
        
    def tearDown(self):
        """
        Clean up after each test.
        """
        # Stop the config patcher
        self.config_patcher.stop()
        
    def start_mock_server(self):
        """
        Start a mock server for testing.
        """
        # This would normally start a real server, but for testing we'll just mock the responses
        pass
        
    def run_async(self, coro):
        """
        Run an async coroutine in the test.
        """
        return asyncio.get_event_loop().run_until_complete(coro)
        
    @patch('requests.post')
    def test_server_proxy_integration(self, mock_post):
        """
        Test that ServerProxy correctly communicates with the external server.
        """
        # Set up the mock response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "message": "Server response",
            "status": "success"
        }
        mock_post.return_value = mock_response
        
        # Create a server proxy
        server_proxy = ServerProxy()
        
        # Forward a request
        response = self.run_async(server_proxy.forward_request(12345, "Test message"))
        
        # Check that the request was made correctly
        mock_post.assert_called_once()
        call_args = mock_post.call_args[0][0]
        self.assertEqual(call_args, self.test_config["EXTERNAL_SERVER_URL"])
        
        # Check the response
        self.assertEqual(response["message"], "Server response")
        self.assertEqual(response["status"], "success")
        
    @patch('src.payment.stripe_gateway.stripe')
    def test_payment_integration_stripe(self, mock_stripe):
        """
        Test that PaymentHandler correctly integrates with Stripe.
        """
        # Set up the mock response
        mock_stripe.PaymentIntent.create.return_value = {
            "id": "pi_test123",
            "client_secret": "secret123",
            "amount": 1000,
            "currency": "usd"
        }
        
        # Create a payment handler
        payment_handler = PaymentHandler()
        
        # Create a payment request
        payment_request = self.run_async(payment_handler.create_payment_request(
            12345, 10.0, "USD", "stripe"
        ))
        
        # Check that Stripe was called correctly
        mock_stripe.PaymentIntent.create.assert_called_once()
        
        # Check the payment request
        self.assertIn("stripe", payment_request.lower())
        self.assertIn("payment", payment_request.lower())
        
    @patch('requests.post')
    def test_admin_panel_integration(self, mock_post):
        """
        Test that AdminPanel correctly handles API requests.
        """
        # Set up the mock response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status": "success",
            "data": {
                "transactions": [
                    {"id": 1, "user_id": 12345, "amount": 10.0, "status": "completed"}
                ]
            }
        }
        mock_post.return_value = mock_response
        
        # Create an admin panel
        admin_panel = AdminPanel()
        
        # Mock the authentication
        admin_panel.authenticate = MagicMock(return_value=True)
        
        # Get transactions
        transactions = admin_panel.get_transactions()
        
        # Check the transactions
        self.assertEqual(len(transactions), 1)
        self.assertEqual(transactions[0]["user_id"], 12345)
        self.assertEqual(transactions[0]["amount"], 10.0)
        
    @patch('src.server_proxy.ServerProxy.forward_request')
    @patch('src.payment_handler.PaymentHandler.create_payment_request')
    def test_end_to_end_flow(self, mock_create_payment, mock_forward_request):
        """
        Test the end-to-end flow of the bot.
        """
        # Set up the mock responses
        mock_forward_request.side_effect = [
            # First response: normal message
            {"message": "Hello, how can I help you?"},
            # Second response: payment required
            {"payment_required": True, "amount": 10.0, "currency": "USD"},
            # Third response: after payment
            {"message": "Thank you for your payment. Here's your premium content."}
        ]
        
        mock_create_payment.return_value = "Please pay $10.00 using this link: [Payment Link](https://example.com/pay)"
        
        # Create a bot with mocked components
        with patch('src.bot.MirrorHandler') as mock_mirror_handler:
            # Set up the mirror handler to use our mocked methods
            mirror_handler_instance = mock_mirror_handler.return_value
            mirror_handler_instance.process_user_message = AsyncMock(side_effect=[
                {"message": "Hello, how can I help you?"},
                {"payment_required": True, "message": "Please pay $10.00 using this link: [Payment Link](https://example.com/pay)"},
                {"message": "Thank you for your payment. Here's your premium content."}
            ])
            
            # Create the bot
            bot = TelegramMirrorBot()
            
            # Create mock update and context
            update = MagicMock()
            context = MagicMock()
            
            # Set up user and message
            update.effective_user.id = 12345
            update.message.text = "Hello"
            update.message.reply_text = AsyncMock()
            update.effective_chat.send_chat_action = AsyncMock()
            
            # Test the first message (normal response)
            self.run_async(bot.handle_message(update, context))
            
            # Check that the response was sent correctly
            update.message.reply_text.assert_called_with("Hello, how can I help you?")
            
            # Reset the mock
            update.message.reply_text.reset_mock()
            
            # Test the second message (payment required)
            update.message.text = "I want premium content"
            self.run_async(bot.handle_message(update, context))
            
            # Check that the payment message was sent correctly
            update.message.reply_text.assert_called_with(
                "Please pay $10.00 using this link: [Payment Link](https://example.com/pay)",
                parse_mode="Markdown"
            )
            
            # Reset the mock
            update.message.reply_text.reset_mock()
            
            # Test the third message (after payment)
            update.message.text = "I've completed the payment"
            self.run_async(bot.handle_message(update, context))
            
            # Check that the thank you message was sent correctly
            update.message.reply_text.assert_called_with("Thank you for your payment. Here's your premium content.")

if __name__ == '__main__':
    unittest.main()
